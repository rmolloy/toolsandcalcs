#!/bin/zsh
set -e
cd "$(dirname "$0")"

port="${TONELAB_TOOLS_PORT:-8080}"
while lsof -nP -iTCP:"$port" -sTCP:LISTEN >/dev/null 2>&1; do
  port=$((port + 1))
done

echo "Starting ToneLab Tools at http://127.0.0.1:$port/"
python3 -m http.server "$port" --bind 127.0.0.1 &
server_pid=$!
trap 'kill "$server_pid" >/dev/null 2>&1 || true' EXIT INT TERM
sleep 1
open "http://127.0.0.1:$port/"
wait "$server_pid"
