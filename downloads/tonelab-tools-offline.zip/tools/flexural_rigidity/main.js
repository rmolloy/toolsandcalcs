"use strict";
(function initFlexuralRigidityUI() {
    const calculator = window.FlexuralRigidity;
    if (!calculator) {
        throw new Error("FlexuralRigidity calculator is unavailable. Ensure calculator.js is loaded first.");
    }
    const calc = calculator;
    const defaults = {
        spanAA: 500,
        topThickness: 4,
        topModulus: 10,
        brace_b: 10,
        brace_count: 2,
        brace_angle: 0,
        brace_modulus: 12,
        bridge_moment: 12,
        bridge_limit: 2
    };
    const fields = {};
    document.querySelectorAll("[data-field]").forEach(element => {
        const key = element.dataset.field;
        if (key)
            fields[key] = element;
    });
    const resultEls = {
        EI: requireElement("result_ei"),
        I: requireElement("result_I"),
        centroid: requireElement("result_centroid"),
        braceHeight: requireElement("result_brace_height"),
        rotation: requireElement("result_rotation"),
        rotationStatus: requireElement("result_rotation_status"),
        status: requireElement("result_status"),
        braceSummary: requireElement("brace_summary")
    };
    const vizEls = {
        svg: requireElement("aa_view"),
        axisX: requireElement("viz_axis_x"),
        axisY: requireElement("viz_axis_y"),
        spanLine: requireElement("viz_span_line"),
        top: requireElement("viz_top"),
        bracesGroup: requireElement("viz_braces"),
        centroid: requireElement("viz_centroid"),
        status: requireElement("viz_status")
    };
    const stackControls = {
        container: requireElement("brace_stack"),
        addSegment: requireElement("add_segment"),
        hint: requireElement("brace_stack_hint"),
    };
    const previewEls = {
        canvas: requireElement("brace_preview"),
        meta: requireElement("brace_preview_meta"),
        summary: requireElement("brace_design_summary"),
    };
    const topPreviewEls = {
        canvas: requireElement("top_preview"),
        meta: requireElement("top_preview_meta"),
    };
    const layoutControls = {
        loadButton: requireElement("load_brace_layout"),
        fileInput: requireElement("brace_layout_file"),
    };
    function requireElement(id) {
        const element = document.getElementById(id);
        if (!element) {
            throw new Error(`Missing element with id ${id}`);
        }
        return element;
    }
    function parseNumber(value) {
        if (value == null || value.trim() === "")
            return NaN;
        const num = Number(value);
        return Number.isFinite(num) ? num : NaN;
    }
    function numberOrDefault(value, fallback) {
        return Number.isFinite(value) ? value : fallback;
    }
    let segmentCounter = 0;
    let braceStack = [];
    let latestValues = null;
    const perTabSession = readFlexuralPerTabSession();
    function nextSegmentId() {
        segmentCounter += 1;
        return `segment-${segmentCounter}`;
    }
    function createStackSegment(partial = {}) {
        var _a, _b, _c;
        return {
            id: nextSegmentId(),
            label: (_a = partial.label) !== null && _a !== void 0 ? _a : "Segment",
            shape: (_b = partial.shape) !== null && _b !== void 0 ? _b : calc.Shapes.RECTANGLE,
            height: (_c = partial.height) !== null && _c !== void 0 ? _c : 4
        };
    }
    function createDefaultStack() {
        return [
            createStackSegment({ label: "Base", shape: calc.Shapes.RECTANGLE, height: 4 }),
            createStackSegment({ label: "Cap", shape: calc.Shapes.TRIANGLE, height: 8 })
        ];
    }
    function cloneStack(stack = braceStack) {
        return stack.map(segment => ({ ...segment }));
    }
    function relabelStack() {
        braceStack = braceStack.map((segment, index) => ({
            ...segment,
            label: index === 0 ? "Base" : `Cap ${index}`
        }));
    }
    braceStack = createDefaultStack();
    const shapeOptions = [
        { value: calc.Shapes.RECTANGLE, label: "Rectangle" },
        { value: calc.Shapes.TRIANGLE, label: "Triangle" },
        { value: calc.Shapes.PARABOLIC, label: "Parabolic" }
    ];
    function updateAddSegmentState() {
        var _a;
        const baseShape = (_a = braceStack[0]) === null || _a === void 0 ? void 0 : _a.shape;
        const canStack = baseShape === calc.Shapes.RECTANGLE;
        stackControls.addSegment.disabled = !canStack;
        if (canStack) {
            stackControls.hint.textContent = "Rectangular bases can stack additional caps. Add as many segments as needed.";
        }
        else {
            stackControls.hint.textContent = "Stacks require a rectangular base. Switch the base shape or edit the single segment.";
        }
    }
    function renderBraceStack() {
        relabelStack();
        stackControls.container.replaceChildren();
        braceStack.forEach((segment, index) => {
            var _a;
            const row = document.createElement("div");
            row.className = "brace-stack-row";
            const title = document.createElement("div");
            title.className = "brace-stack-label";
            title.textContent = (_a = segment.label) !== null && _a !== void 0 ? _a : `Segment ${index + 1}`;
            const shapeField = document.createElement("div");
            shapeField.className = "brace-stack-field";
            const shapeLabel = document.createElement("span");
            shapeLabel.textContent = "Shape";
            const shapeSelect = document.createElement("select");
            shapeSelect.className = "brace-stack-select";
            shapeOptions.forEach(option => {
                const opt = document.createElement("option");
                opt.value = option.value;
                opt.textContent = option.label;
                shapeSelect.append(opt);
            });
            shapeSelect.value = segment.shape;
            shapeSelect.addEventListener("change", () => {
                updateBraceSegment(segment.id, { shape: shapeSelect.value });
            });
            shapeField.append(shapeLabel, shapeSelect);
            const heightField = document.createElement("div");
            heightField.className = "brace-stack-field";
            const heightLabel = document.createElement("span");
            heightLabel.textContent = "Height (mm)";
            const heightInput = document.createElement("input");
            heightInput.className = "brace-stack-input";
            heightInput.type = "number";
            heightInput.min = "0";
            heightInput.step = "0.5";
            heightInput.value = segment.height.toString();
            heightInput.addEventListener("input", () => {
                updateBraceSegment(segment.id, { height: Number(heightInput.value) });
            });
            heightField.append(heightLabel, heightInput);
            const removeButton = document.createElement("button");
            removeButton.className = "brace-stack-remove";
            removeButton.type = "button";
            removeButton.textContent = "Remove";
            removeButton.disabled = braceStack.length === 1;
            removeButton.addEventListener("click", () => removeBraceSegment(segment.id));
            row.append(title, shapeField, heightField, removeButton);
            stackControls.container.append(row);
        });
        updateAddSegmentState();
        updateDesignSummary();
        renderBracePreview(latestValues);
    }
    function renderTopProfile(values) {
        var _a, _b, _c, _d;
        const span = numberOrDefault((_a = values === null || values === void 0 ? void 0 : values.spanAA) !== null && _a !== void 0 ? _a : parseNumber((_b = fields.spanAA) === null || _b === void 0 ? void 0 : _b.value), defaults.spanAA);
        const thickness = numberOrDefault((_c = values === null || values === void 0 ? void 0 : values.topThickness) !== null && _c !== void 0 ? _c : parseNumber((_d = fields.topThickness) === null || _d === void 0 ? void 0 : _d.value), defaults.topThickness);
        const svgWidth = 140;
        const svgHeight = 60;
        const rectHeight = Math.max(6, Math.min(svgHeight, (thickness / 10) * svgHeight));
        const rectY = (svgHeight - rectHeight) / 2;
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", `0 0 ${svgWidth} ${svgHeight}`);
        svg.setAttribute("width", `${svgWidth}`);
        svg.setAttribute("height", `${svgHeight}`);
        const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        rect.setAttribute("x", "0");
        rect.setAttribute("y", rectY.toString());
        rect.setAttribute("width", svgWidth.toString());
        rect.setAttribute("height", rectHeight.toString());
        rect.setAttribute("fill", "var(--blue)");
        const outline = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        outline.setAttribute("x", "0");
        outline.setAttribute("y", rectY.toString());
        outline.setAttribute("width", svgWidth.toString());
        outline.setAttribute("height", rectHeight.toString());
        outline.setAttribute("fill", "none");
        outline.setAttribute("stroke", "rgba(255,255,255,0.7)");
        outline.setAttribute("stroke-width", "1.4");
        svg.append(rect, outline);
        topPreviewEls.canvas.replaceChildren(svg);
        topPreviewEls.meta.textContent = `${format(span, 0)} × ${format(thickness, 1)} mm`;
    }
    function updateDesignSummary() {
        const labels = braceStack.map((segment) => segment.label || "").filter(Boolean).join(" / ");
        const detail = labels
            ? `Segments (${braceStack.length}) — ${labels}`
            : `Segments (${braceStack.length})`;
        previewEls.summary.innerHTML = `
      <span class="design-label">Design</span>
      <span class="design-detail">${detail}</span>
    `;
    }
    function renderBracePreview(values) {
        var _a, _b;
        if (!previewEls.canvas)
            return;
        const widthValue = numberOrDefault((_a = values === null || values === void 0 ? void 0 : values.brace_b) !== null && _a !== void 0 ? _a : parseNumber((_b = fields.brace_b) === null || _b === void 0 ? void 0 : _b.value), defaults.brace_b);
        const totalHeight = braceStack.reduce((sum, segment) => sum + Math.max(0, segment.height), 0);
        const svgWidth = 140;
        const mmScale = svgWidth / Math.max(widthValue, 1);
        const previewHeight = Math.max(totalHeight, 1) * mmScale || 1;
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", `0 0 ${svgWidth} ${previewHeight}`);
        svg.setAttribute("width", `${svgWidth}`);
        svg.setAttribute("height", `${previewHeight}`);
        let currentY = previewHeight;
        braceStack.forEach((segment) => {
            const segHeight = Math.max(0, segment.height);
            if (segHeight <= 0)
                return;
            const segHeightPx = segHeight * mmScale;
            const topY = currentY - segHeightPx;
            const x = 0;
            const segWidthPx = svgWidth;
            let element;
            if (segment.shape === calc.Shapes.TRIANGLE) {
                element = document.createElementNS("http://www.w3.org/2000/svg", "path");
                element.setAttribute("d", `M${x} ${currentY} L${x + segWidthPx} ${currentY} L${x + segWidthPx / 2} ${topY} Z`);
            }
            else if (segment.shape === calc.Shapes.PARABOLIC) {
                element = document.createElementNS("http://www.w3.org/2000/svg", "path");
                const mid = x + segWidthPx / 2;
                element.setAttribute("d", `M${x} ${currentY} L${x + segWidthPx} ${currentY} Q${mid} ${topY} ${x} ${currentY} Z`);
            }
            else {
                element = document.createElementNS("http://www.w3.org/2000/svg", "rect");
                element.setAttribute("x", String(x));
                element.setAttribute("y", String(topY));
                element.setAttribute("width", String(segWidthPx));
                element.setAttribute("height", String(segHeightPx));
            }
            element.setAttribute("fill", segmentColor(segment.shape));
            svg.append(element);
            const outline = element.cloneNode(false);
            outline.setAttribute("fill", "none");
            outline.setAttribute("stroke", "rgba(255,255,255,0.7)");
            outline.setAttribute("stroke-width", "1.4");
            svg.append(outline);
            currentY = topY;
        });
        previewEls.canvas.replaceChildren(svg);
        previewEls.meta.textContent = `${format(widthValue, 1)} × ${format(totalHeight, 1)} mm`;
    }
    function segmentColor(shape) {
        if (shape === calc.Shapes.TRIANGLE)
            return "var(--orange)";
        if (shape === calc.Shapes.PARABOLIC)
            return "var(--yellow)";
        return "var(--blue)";
    }
    function addBraceSegment() {
        const newHeight = braceStack.length > 0 ? Math.max(1, braceStack[braceStack.length - 1].height) : 4;
        braceStack = [
            ...braceStack,
            createStackSegment({
                label: `Cap ${braceStack.length}`,
                shape: calc.Shapes.TRIANGLE,
                height: newHeight
            })
        ];
        renderBraceStack();
        run();
    }
    function updateBraceSegment(id, updates) {
        braceStack = braceStack.map(segment => {
            var _a;
            if (segment.id !== id)
                return segment;
            const nextHeight = updates.height != null && Number.isFinite(updates.height) ? Math.max(0, updates.height) : segment.height;
            const nextShape = (_a = updates.shape) !== null && _a !== void 0 ? _a : segment.shape;
            return {
                ...segment,
                ...updates,
                height: nextHeight,
                shape: nextShape
            };
        });
        updateAddSegmentState();
        run();
    }
    function removeBraceSegment(id) {
        if (braceStack.length === 1)
            return;
        braceStack = braceStack.filter(segment => segment.id !== id);
        if (braceStack.length === 0) {
            braceStack = [createStackSegment({ label: "Base" })];
        }
        renderBraceStack();
        run();
    }
    function readInputs() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        return {
            spanAA: parseNumber((_a = fields.spanAA) === null || _a === void 0 ? void 0 : _a.value),
            topThickness: parseNumber((_b = fields.topThickness) === null || _b === void 0 ? void 0 : _b.value),
            topModulus: parseNumber((_c = fields.topModulus) === null || _c === void 0 ? void 0 : _c.value),
            brace_b: parseNumber((_d = fields.brace_b) === null || _d === void 0 ? void 0 : _d.value),
            brace_count: parseNumber((_e = fields.brace_count) === null || _e === void 0 ? void 0 : _e.value),
            brace_angle: parseNumber((_f = fields.brace_angle) === null || _f === void 0 ? void 0 : _f.value),
            brace_modulus: parseNumber((_g = fields.brace_modulus) === null || _g === void 0 ? void 0 : _g.value),
            bridge_moment: parseNumber((_h = fields.bridge_moment) === null || _h === void 0 ? void 0 : _h.value),
            bridge_limit: parseNumber((_j = fields.bridge_limit) === null || _j === void 0 ? void 0 : _j.value),
            braceSegments: cloneStack()
        };
    }
    function buildBrace(values) {
        const braceModulusNmm2 = numberOrDefault(values.brace_modulus, defaults.brace_modulus) * 1000;
        const planWidth = numberOrDefault(values.brace_b, defaults.brace_b);
        const rawAngle = Number.isFinite(values.brace_angle) ? values.brace_angle : 0;
        const angleFromPerp = calc.clamp(rawAngle, 0, 89.9);
        const phiDeg = 90 - angleFromPerp;
        const stack = values.braceSegments
            .map((segment, index) => {
            var _a;
            return ({
                shape: segment.shape,
                h: Math.max(0, segment.height),
                label: (_a = segment.label) !== null && _a !== void 0 ? _a : `segment ${index + 1}`,
                material: { E: braceModulusNmm2 }
            });
        })
            .filter(segment => segment.h > 0);
        return {
            w_plan: planWidth,
            phi_deg: phiDeg,
            segments: stack
        };
    }
    function computeBraceOffsets(span, braceWidth, count) {
        const spanValue = Number.isFinite(span) ? span : defaults.spanAA;
        const width = Number.isFinite(braceWidth) ? braceWidth : defaults.brace_b;
        const n = Math.max(1, count);
        const halfSpan = spanValue / 2;
        const totalBraceWidth = width * n;
        if (totalBraceWidth >= spanValue) {
            const start = -halfSpan + width / 2;
            return Array.from({ length: n }, (_, index) => start + index * width);
        }
        const gap = (spanValue - totalBraceWidth) / (n + 1);
        const start = -halfSpan + gap + width / 2;
        const step = width + gap;
        return Array.from({ length: n }, (_, index) => start + index * step);
    }
    function resolveBraceCount(raw) {
        return Number.isFinite(raw) ? Math.max(1, Math.round(raw)) : 1;
    }
    function buildBraceSet(values) {
        const count = resolveBraceCount(values.brace_count);
        return {
            models: Array.from({ length: count }, () => buildBrace(values)),
            offsets: computeBraceOffsets(values.spanAA, values.brace_b, count)
        };
    }
    function computeRotation(values, EI) {
        const momentNmm = numberOrDefault(values.bridge_moment, defaults.bridge_moment) * 1e3;
        const safeEI = EI > 0 ? EI : Number.EPSILON;
        const rotationDeg = momentNmm / safeEI * (180 / Math.PI);
        const limit = values.bridge_limit;
        const rotationPass = Number.isFinite(limit) ? rotationDeg <= limit : true;
        return { rotationDeg, rotationPass };
    }
    function buildVizState(values, offsets, slice) {
        return {
            span: numberOrDefault(values.spanAA, defaults.spanAA),
            topThickness: numberOrDefault(values.topThickness, defaults.topThickness),
            braces: offsets.map((offset, index) => {
                var _a, _b, _c, _d;
                return ({
                    offset,
                    height: (_d = (_b = (_a = slice.braces[index]) === null || _a === void 0 ? void 0 : _a.height) !== null && _b !== void 0 ? _b : (_c = slice.braces[0]) === null || _c === void 0 ? void 0 : _c.height) !== null && _d !== void 0 ? _d : 0,
                    width: numberOrDefault(values.brace_b, defaults.brace_b)
                });
            })
        };
    }
    function annotateBraceRigidity(values, slice) {
        const modulus = numberOrDefault(values.topModulus, defaults.topModulus) * 1000;
        const annotated = slice.braces.map((brace, index) => {
            const EIbrace = modulus * brace.transformedI;
            console.debug(`[FlexuralRigidity] Brace ${index + 1} EI: ${EIbrace.toFixed(2)} N·mm²`);
            return { ...brace, EI: EIbrace };
        });
        return { ...slice, braces: annotated };
    }
    function format(value, digits = 2) {
        if (!Number.isFinite(value))
            return "—";
        return new Intl.NumberFormat("en-US", {
            minimumFractionDigits: digits,
            maximumFractionDigits: digits
        }).format(value);
    }
    function renderBraceSummary(braces) {
        const container = resultEls.braceSummary;
        container.innerHTML = "";
        braces.forEach((brace, index) => {
            const card = document.createElement("div");
            card.className = "brace-summary-card";
            const title = document.createElement("h4");
            title.textContent = `Brace ${index + 1}`;
            const eiRow = document.createElement("div");
            eiRow.className = "brace-summary-metric";
            eiRow.innerHTML = `<span>EI (N·m²)</span><span>${format(brace.EI / 1e6, 3)}</span>`;
            const iRow = document.createElement("div");
            iRow.className = "brace-summary-metric";
            iRow.innerHTML = `<span>I (mm⁴)</span><span>${format(brace.transformedI, 1)}</span>`;
            card.append(title, eiRow, iRow);
            container.append(card);
        });
    }
    function setResults(slice) {
        var _a;
        const eiNm2 = slice.EI / 1e6;
        resultEls.EI.textContent = format(eiNm2, 3);
        resultEls.I.textContent = format(slice.transformedI, 1);
        resultEls.centroid.textContent = `${format(slice.centroid, 2)} mm`;
        const braceHeight = (_a = slice.braces[0]) === null || _a === void 0 ? void 0 : _a.height;
        resultEls.braceHeight.textContent = braceHeight ? `${format(braceHeight, 1)} mm` : "—";
        if (slice.rotationDeg != null) {
            resultEls.rotation.textContent = `${format(slice.rotationDeg, 3)} °`;
            resultEls.rotationStatus.textContent = slice.rotationPass ? "OK" : "Over limit";
            resultEls.rotationStatus.style.color = slice.rotationPass ? "var(--muted)" : "var(--orange)";
        }
        else {
            resultEls.rotation.textContent = "—";
            resultEls.rotationStatus.textContent = "—";
            resultEls.rotationStatus.style.color = "var(--muted)";
        }
        resultEls.status.textContent = "Live: computed from current inputs.";
        renderBraceSummary(slice.braces);
    }
    function setError(message) {
        resultEls.EI.textContent = "—";
        resultEls.I.textContent = "—";
        resultEls.centroid.textContent = "—";
        resultEls.braceHeight.textContent = "—";
        resultEls.rotation.textContent = "—";
        resultEls.rotationStatus.textContent = "—";
        resultEls.rotationStatus.style.color = "var(--muted)";
        resultEls.status.textContent = message;
    }
    function run() {
        persistFlexuralPerTabSession();
        try {
            const values = readInputs();
            latestValues = values;
            renderTopProfile(values);
            renderBracePreview(values);
            const { models: braceModels, offsets } = buildBraceSet(values);
            const slice = calc.computeSlice({
                spanAA: numberOrDefault(values.spanAA, defaults.spanAA),
                topThickness: numberOrDefault(values.topThickness, defaults.topThickness),
                topModulus: numberOrDefault(values.topModulus, defaults.topModulus) * 1000,
                braces: braceModels
            });
            const { rotationDeg, rotationPass } = computeRotation(values, slice.EI);
            const sliceWithRigidity = annotateBraceRigidity(values, slice);
            const vizState = buildVizState(values, offsets, sliceWithRigidity);
            setResults({ ...sliceWithRigidity, rotationDeg, rotationPass });
            renderViz(vizState, sliceWithRigidity);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            setError(message);
        }
    }
    document.querySelectorAll("input[data-field], select[data-field]").forEach(element => {
        const eventType = element.tagName === "SELECT" ? "change" : "input";
        element.addEventListener(eventType, () => run());
    });
    stackControls.addSegment.addEventListener("click", () => addBraceSegment());
    layoutControls.loadButton.addEventListener("click", () => layoutControls.fileInput.click());
    layoutControls.fileInput.addEventListener("change", (event) => handleBraceLayoutFile(event));
    async function handleBraceLayoutFile(event) {
        var _a;
        const input = event.target;
        const file = (_a = input.files) === null || _a === void 0 ? void 0 : _a[0];
        if (!file)
            return;
        try {
            const text = await file.text();
            const raw = JSON.parse(text);
            const braceArray = Array.isArray(raw) ? raw : Array.isArray(raw === null || raw === void 0 ? void 0 : raw.braces) ? raw.braces : [];
            if (!braceArray.length)
                throw new Error("No braces found in layout.");
            let index = 0;
            if (braceArray.length > 1) {
                const options = braceArray.map((brace, idx) => `${idx + 1}. ${brace.name || `Brace ${idx + 1}`}`).join("\n");
                const choice = window.prompt(`Select brace to import:\n${options}`, "1");
                const parsed = choice != null ? Number(choice) - 1 : 0;
                if (Number.isFinite(parsed) && parsed >= 0 && parsed < braceArray.length) {
                    index = parsed;
                }
            }
            applyImportedBrace(braceArray[index]);
        }
        catch (err) {
            console.error("[FlexRigidity] Brace layout import failed", err);
            window.alert("Unable to load brace layout. Please verify the file and try again.");
        }
        finally {
            layoutControls.fileInput.value = "";
        }
    }
    function applyImportedBrace(data) {
        var _a, _b, _c;
        if (!((_a = data === null || data === void 0 ? void 0 : data.segments) === null || _a === void 0 ? void 0 : _a.length))
            throw new Error("Brace layout missing segments.");
        braceStack = data.segments.map((segment, index) => ({
            id: nextSegmentId(),
            label: segment.label || (index === 0 ? "Base" : `Segment ${index + 1}`),
            shape: normalizeShape(segment.shape),
            height: Math.max(0, Number(segment.height) || 0),
        })).filter((segment) => segment.height > 0);
        if (!braceStack.length)
            throw new Error("No valid segments in brace layout.");
        const lastBreadth = Number((_b = data.segments[data.segments.length - 1]) === null || _b === void 0 ? void 0 : _b.breadth);
        if (Number.isFinite(lastBreadth) && fields.brace_b) {
            fields.brace_b.value = String(lastBreadth);
        }
        const firstModulus = Number((_c = data.segments[0]) === null || _c === void 0 ? void 0 : _c.modulus);
        if (Number.isFinite(firstModulus) && fields.brace_modulus) {
            fields.brace_modulus.value = String(firstModulus);
        }
        renderBraceStack();
        run();
    }
    function normalizeShape(value) {
        const normalized = typeof value === "string" ? value.toLowerCase() : "";
        if (normalized.includes("tri"))
            return calc.Shapes.TRIANGLE;
        if (normalized.includes("para"))
            return calc.Shapes.PARABOLIC;
        if (normalized.includes("rect"))
            return calc.Shapes.RECTANGLE;
        return calc.Shapes.RECTANGLE;
    }
    function reset() {
        Object.entries(defaults).forEach(([key, value]) => {
            const field = fields[key];
            if (!field)
                return;
            if (field instanceof HTMLSelectElement) {
                field.value = String(value);
            }
            else {
                field.value = String(value);
            }
        });
        braceStack = createDefaultStack();
        restoreFlexuralPerTabSession();
        renderBraceStack();
        run();
    }
    function readFlexuralPerTabSession() {
        var _a;
        return ((_a = window.PerTabToolSession) === null || _a === void 0 ? void 0 : _a.perTabToolSessionCreate)
            ? window.PerTabToolSession.perTabToolSessionCreate({ toolId: "flexural_rigidity", version: 1 })
            : null;
    }
    function persistFlexuralPerTabSession() {
        perTabSession === null || perTabSession === void 0 ? void 0 : perTabSession.write({
            fields: Object.fromEntries(Object.entries(fields).map(([key, field]) => [key, field.value])),
            braceStack: cloneStack(),
        });
    }
    function restoreFlexuralPerTabSession() {
        const snapshot = perTabSession === null || perTabSession === void 0 ? void 0 : perTabSession.read();
        if (!snapshot) {
            return;
        }
        Object.entries(snapshot.fields || {}).forEach(([key, value]) => {
            if (fields[key]) {
                fields[key].value = String(value !== null && value !== void 0 ? value : "");
            }
        });
        if (Array.isArray(snapshot.braceStack) && snapshot.braceStack.length) {
            braceStack = snapshot.braceStack.map((segment, index) => createStackSegment({
                label: segment.label || (index === 0 ? "Base" : `Cap ${index}`),
                shape: normalizeShape(segment.shape),
                height: Math.max(0, Number(segment.height) || 0),
            }));
        }
    }
    reset();
    function renderViz(dimensions, slice) {
        const width = 700;
        const padding = 24;
        const span = Math.max(dimensions.span || 1, 1);
        const baseSpan = span <= 500 ? 500 : span * 1.2;
        const topH = Math.max(dimensions.topThickness || 0, 0);
        const braceHeights = dimensions.braces.map(b => Math.max(b.height || 0, 0));
        const maxBraceH = braceHeights.length ? Math.max(...braceHeights) : 0;
        const totalH = Math.max(topH + maxBraceH, 1);
        const baseScale = (width - 2 * padding) / baseSpan;
        const scaleX = baseScale;
        const scaleY = baseScale;
        const spanPx = span * scaleX;
        const spanDraw = Math.min(spanPx, width - 2 * padding);
        const offsetX = (width - spanDraw) / 2;
        const viewHeight = padding * 2 + Math.max(totalH * scaleY, padding);
        vizEls.svg.setAttribute("viewBox", `0 0 ${width} ${viewHeight}`);
        vizEls.svg.style.height = `${viewHeight}px`;
        const baseY = viewHeight - padding;
        vizEls.spanLine.setAttribute("x1", offsetX.toString());
        vizEls.spanLine.setAttribute("x2", (offsetX + spanDraw).toString());
        vizEls.spanLine.setAttribute("y1", baseY.toString());
        vizEls.spanLine.setAttribute("y2", baseY.toString());
        vizEls.axisX.setAttribute("x1", offsetX.toString());
        vizEls.axisX.setAttribute("x2", (offsetX + spanDraw).toString());
        vizEls.axisX.setAttribute("y1", baseY.toString());
        vizEls.axisX.setAttribute("y2", baseY.toString());
        vizEls.axisY.setAttribute("x1", offsetX.toString());
        vizEls.axisY.setAttribute("x2", offsetX.toString());
        vizEls.axisY.setAttribute("y1", baseY.toString());
        vizEls.axisY.setAttribute("y2", (baseY - totalH * scaleY).toString());
        const topY = baseY - topH * scaleY;
        vizEls.top.setAttribute("x", offsetX.toString());
        vizEls.top.setAttribute("y", topY.toString());
        vizEls.top.setAttribute("width", spanDraw.toString());
        vizEls.top.setAttribute("height", Math.max(topH * scaleY, 1).toString());
        vizEls.bracesGroup.replaceChildren();
        const centerX = offsetX + spanDraw / 2;
        dimensions.braces.forEach(brace => {
            const widthMm = Math.max(1, brace.width || 0);
            const widthPx = widthMm * scaleX;
            const braceX = centerX + (brace.offset || 0) * scaleX - widthPx / 2;
            let currentY = topY;
            braceStack.forEach((segment) => {
                const segHeight = Math.max(0, segment.height);
                if (segHeight <= 0)
                    return;
                const segHeightPx = segHeight * scaleY;
                const topSegmentY = currentY - segHeightPx;
                let element;
                if (segment.shape === calc.Shapes.TRIANGLE) {
                    element = document.createElementNS("http://www.w3.org/2000/svg", "path");
                    element.setAttribute("d", `M${braceX} ${currentY} L${braceX + widthPx} ${currentY} L${braceX + widthPx / 2} ${topSegmentY} Z`);
                }
                else if (segment.shape === calc.Shapes.PARABOLIC) {
                    element = document.createElementNS("http://www.w3.org/2000/svg", "path");
                    const mid = braceX + widthPx / 2;
                    element.setAttribute("d", `M${braceX} ${currentY} L${braceX + widthPx} ${currentY} Q${mid} ${topSegmentY} ${braceX} ${currentY} Z`);
                }
                else {
                    element = document.createElementNS("http://www.w3.org/2000/svg", "rect");
                    element.setAttribute("x", braceX.toString());
                    element.setAttribute("y", topSegmentY.toString());
                    element.setAttribute("width", Math.max(widthPx, 1).toString());
                    element.setAttribute("height", Math.max(segHeightPx, 1).toString());
                }
                element.setAttribute("fill", segmentColor(segment.shape));
                element.setAttribute("fill-opacity", "0.55");
                const outline = element.cloneNode(false);
                outline.setAttribute("fill", "none");
                outline.setAttribute("stroke", "rgba(255,255,255,0.7)");
                outline.setAttribute("stroke-width", "1.2");
                vizEls.bracesGroup.appendChild(element);
                vizEls.bracesGroup.appendChild(outline);
                currentY = topSegmentY;
            });
        });
        const centroidY = baseY - (slice.centroid || 0) * scaleY;
        vizEls.centroid.setAttribute("x1", offsetX.toString());
        vizEls.centroid.setAttribute("x2", (offsetX + spanDraw).toString());
        vizEls.centroid.setAttribute("y1", centroidY.toString());
        vizEls.centroid.setAttribute("y2", centroidY.toString());
        const reference = span <= 500 ? "500 mm reference" : `${format(baseSpan, 0)} mm span (+20%)`;
        vizEls.status.textContent = `Span: ${format(span, 0)} mm (${reference}) · Total height: ${format(totalH, 1)} mm · Braces: ${dimensions.braces.length}`;
    }
})();
