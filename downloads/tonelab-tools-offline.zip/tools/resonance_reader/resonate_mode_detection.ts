import { modeBands } from "./resonate_mode_config.js";
import { median } from "./resonate_mode_metrics.js";
import { resonanceParabolicPeakRefineEnabled } from "./resonate_debug_flags.js";

export type ModeDetection = {
  mode: string;
  peakFreq: number | null;
  peakDb: number | null;
  peakIdx: number | null;
  prominenceDb: number | null;
};

export function smoothSpectrumFast(freqs: number[], mags: number[], smoothHz: number): number[] {
  if (!smoothHz || smoothHz <= 0) return mags;
  if (freqs.length < 3 || mags.length < 3) return mags;
  const bw = Math.abs(freqs[1] - freqs[0]);
  if (!Number.isFinite(bw) || bw <= 0) return mags;
  const r = Math.max(1, Math.round(smoothHz / bw));
  const n = mags.length;
  const prefix = new Float64Array(n + 1);
  const prefixIdx = new Float64Array(n + 1);
  for (let i = 0; i < n; i += 1) {
    const v = mags[i];
    prefix[i + 1] = prefix[i] + v;
    prefixIdx[i + 1] = prefixIdx[i] + v * i;
  }
  const sumRange = (a: number, b: number) => prefix[b + 1] - prefix[a];
  const sumIdxRange = (a: number, b: number) => prefixIdx[b + 1] - prefixIdx[a];

  const out = new Array<number>(n);
  const denom = r;
  for (let i = 0; i < n; i += 1) {
    const lo = Math.max(0, i - r);
    const hi = Math.min(n - 1, i + r);
    const leftLo = lo;
    const leftHi = Math.max(lo, i - 1);
    const rightLo = Math.min(hi, i + 1);
    const rightHi = hi;

    let acc = mags[i];
    let wSum = 1;

    if (leftHi >= leftLo && i - 1 >= lo) {
      const count = leftHi - leftLo + 1;
      const base = 1 + i / denom;
      const sumV = sumRange(leftLo, leftHi);
      const sumIV = sumIdxRange(leftLo, leftHi);
      acc += base * sumV - (1 / denom) * sumIV;
      wSum += count * base - (1 / denom) * ((leftLo + leftHi) * count / 2);
    }
    if (rightHi >= rightLo && i + 1 <= hi) {
      const count = rightHi - rightLo + 1;
      const base = 1 - i / denom;
      const sumV = sumRange(rightLo, rightHi);
      const sumIV = sumIdxRange(rightLo, rightHi);
      acc += base * sumV + (1 / denom) * sumIV;
      wSum += count * base + (1 / denom) * ((rightLo + rightHi) * count / 2);
    }
    out[i] = wSum > 0 ? acc / wSum : mags[i];
  }
  return out;
}

export function smoothSpectrumGaussianBins(mags: number[], sigmaBins: number): number[] {
  if (!sigmaBins || sigmaBins <= 0) return mags;
  if (mags.length < 3) return mags;
  const kernel = gaussianKernelBuild(sigmaBins);
  const halfSize = Math.floor(kernel.length / 2);
  const out = new Array<number>(mags.length);
  for (let i = 0; i < mags.length; i += 1) {
    let value = 0;
    for (let j = -halfSize; j <= halfSize; j += 1) {
      const index = i + j;
      if (index >= 0 && index < mags.length) value += mags[index] * kernel[j + halfSize];
    }
    out[i] = value;
  }
  return out;
}

function gaussianKernelBuild(sigmaBins: number) {
  const kernelSize = (Math.ceil(sigmaBins * 3) * 2) + 1;
  const kernel = new Array<number>(kernelSize);
  const halfSize = Math.floor(kernelSize / 2);
  let sum = 0;
  for (let i = -halfSize; i <= halfSize; i += 1) {
    const value = Math.exp(-(i * i) / (2 * sigmaBins * sigmaBins));
    kernel[i + halfSize] = value;
    sum += value;
  }
  return kernel.map((value) => value / sum);
}

function refineParabolicPeak(freqs: number[], ys: number[], idx: number): { freq: number; y: number; delta: number } | null {
  if (idx <= 0 || idx >= ys.length - 1) return null;
  const a = ys[idx - 1];
  const b = ys[idx];
  const c = ys[idx + 1];
  if (!Number.isFinite(a) || !Number.isFinite(b) || !Number.isFinite(c)) return null;
  const bw = freqs.length > 1 ? Math.abs(freqs[1] - freqs[0]) : null;
  if (!bw || !Number.isFinite(bw) || bw <= 0) return null;
  const denom = a - (2 * b) + c;
  if (!Number.isFinite(denom) || Math.abs(denom) < 1e-12) return null;
  const delta = 0.5 * (a - c) / denom;
  if (!Number.isFinite(delta)) return null;
  const clamped = Math.max(-1, Math.min(1, delta));
  const freq = freqs[idx] + clamped * bw;
  const y = b - ((a - c) * clamped) / 4;
  return { freq, y, delta: clamped };
}

export function analyzeModes(spectrum: { freqs: number[]; dbs: number[] }): ModeDetection[] {
  return analyzeModesWithBands(spectrum, modeBands);
}

export function analyzeModesWithBands(
  spectrum: { freqs: number[]; dbs: number[] },
  bands: Record<string, { low: number; high: number }>,
): ModeDetection[] {
  const { freqs, dbs } = spectrum;
  return Object.entries(bands).map(([key, band]) => {
    const peaks: { idx: number; db: number; prominence: number }[] = [];
    for (let i = 1; i < freqs.length - 1; i += 1) {
      if (!(dbs[i] > dbs[i - 1] && dbs[i] > dbs[i + 1])) continue;
      const f = freqs[i];
      if (f < band.low || f > band.high) continue;
      const start = Math.max(0, i - 6);
      const end = Math.min(dbs.length - 1, i + 6);
      const neighbors = dbs.slice(start, end + 1);
      neighbors.splice(i - start, 1);
      const baseline = neighbors.length ? median(neighbors) : dbs[i];
      const prominence = dbs[i] - baseline;
      peaks.push({ idx: i, db: dbs[i], prominence });
    }
    if (!peaks.length) return { mode: key, peakFreq: null, peakDb: null, peakIdx: null, prominenceDb: null };
    peaks.sort((a, b) => b.db - a.db);
    const primary = peaks[0];
    const refined = resonanceParabolicPeakRefineEnabled() ? refineParabolicPeak(freqs, dbs, primary.idx) : null;
    if (refined) return { mode: key, peakFreq: refined.freq, peakDb: refined.y, peakIdx: primary.idx, prominenceDb: primary.prominence };
    return { mode: key, peakFreq: freqs[primary.idx], peakDb: dbs[primary.idx], peakIdx: primary.idx, prominenceDb: primary.prominence };
  });
}
