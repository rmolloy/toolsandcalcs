import { plateMaterialPanelVisibleForMeasureMode } from "./resonate_plate_material_panel.js";
import { measureModeNormalize, type MeasureMode } from "./resonate_mode_config.js";

export type AnalysisTab = "peak_analysis" | "material_properties";

const DEFAULT_ANALYSIS_TAB: AnalysisTab = "peak_analysis";
const WAVEFORM_NAVIGATOR_COPY = {
  title: "Frequency Response",
  description: "Drag yellow range for FFT analysis. Drag green range for note selection. Click a note label (or Option/Command-click a note slice) to override its note.",
};
const PEAK_ANALYSIS_TAP_NAVIGATOR_COPY = {
  title: "Tap Navigator",
  description: "Select a tap to inspect its Peak/Q ring-down. Every marker is a detected tap.",
};

export function analysisTabsInitialize(state: Record<string, any>) {
  analysisTabSeedIntoState(state);
  analysisTabsBindOnce(state);
  analysisTabsRenderFromState(state);
}

export function analysisTabsRenderFromState(state: Record<string, any>) {
  analysisTabSeedIntoState(state);
  analysisTabNormalizeForState(state);
  analysisSurfaceRenderFromState(state);
  analysisTabsRenderButtonsFromState(state);
  analysisTabsRenderPanelsFromState(state);
}

export function analysisTabActivatePeakAnalysis(state: Record<string, any>) {
  analysisTabWrite(state, DEFAULT_ANALYSIS_TAB);
  analysisTabsRenderFromState(state);
}

export function analysisTabMaterialVisibleForMeasureMode(measureMode: unknown) {
  return plateMaterialPanelVisibleForMeasureMode(measureMode);
}

export function analysisSurfaceVisibleForMeasureMode(measureMode: unknown) {
  return measureModeNormalize(measureMode) === "peak_analysis";
}

export function waveformNavigatorCopyResolveForMeasureMode(measureMode: unknown) {
  return measureModeNormalize(measureMode) === "peak_analysis"
    ? PEAK_ANALYSIS_TAP_NAVIGATOR_COPY
    : WAVEFORM_NAVIGATOR_COPY;
}

function analysisTabSeedIntoState(state: Record<string, any>) {
  if (analysisTabValid(state.analysisActiveTab)) return;
  state.analysisActiveTab = DEFAULT_ANALYSIS_TAB;
}

function analysisTabsBindOnce(state: Record<string, any>) {
  const root = analysisSurfaceElementGet();
  if (!root || root.dataset.bound === "true") return;
  root.dataset.bound = "true";
  analysisTabButtonsBuild().forEach((button) => {
    button.addEventListener("click", () => analysisTabClickHandle(state, button));
  });
}

function analysisTabClickHandle(state: Record<string, any>, button: HTMLButtonElement) {
  const nextTab = analysisTabFromButton(button);
  if (!nextTab) return;
  if (nextTab === "material_properties" && !analysisTabMaterialVisibleForMeasureMode(state.measureMode)) return;
  analysisTabWrite(state, nextTab);
  analysisTabsRenderFromState(state);
}

function analysisTabNormalizeForState(state: Record<string, any>) {
  if (!analysisTabMaterialVisibleForMeasureMode(state.measureMode) && state.analysisActiveTab === "material_properties") {
    analysisTabWrite(state, DEFAULT_ANALYSIS_TAB);
  }
}

function analysisTabsRenderButtonsFromState(state: Record<string, any>) {
  const activeTab = analysisTabReadFromState(state);
  const materialVisible = analysisTabMaterialVisibleForMeasureMode(state.measureMode);
  analysisTabButtonsBuild().forEach((button) => {
    const tab = analysisTabFromButton(button);
    if (!tab) return;
    const visible = tab !== "material_properties" || materialVisible;
    button.hidden = !visible;
    button.setAttribute("aria-selected", String(visible && tab === activeTab));
    button.classList.toggle("is-active", visible && tab === activeTab);
  });
}

function analysisTabsRenderPanelsFromState(state: Record<string, any>) {
  const activeTab = analysisTabReadFromState(state);
  const materialVisible = analysisTabMaterialVisibleForMeasureMode(state.measureMode);
  const peakPanel = document.getElementById("peak_analysis_panel") as HTMLElement | null;
  if (peakPanel) peakPanel.hidden = activeTab !== "peak_analysis";
  const materialPanel = document.getElementById("plate_material_card") as HTMLElement | null;
  if (materialPanel) materialPanel.hidden = !materialVisible || activeTab !== "material_properties";
}

function analysisSurfaceRenderFromState(state: Record<string, any>) {
  const surface = analysisSurfaceElementGet();
  if (!surface) return;
  const measureMode = measureModeNormalize(state.measureMode);
  analysisSurfaceParentModeWrite(surface, measureMode);
  waveformNavigatorCopyRenderForMeasureMode(measureMode);
  surface.hidden = !analysisSurfaceVisibleForMeasureMode(measureMode);
}

function waveformNavigatorCopyRenderForMeasureMode(measureMode: MeasureMode) {
  const copy = waveformNavigatorCopyResolveForMeasureMode(measureMode);
  const title = document.getElementById("wave_nav_title");
  const description = document.getElementById("wave_nav_description");
  if (title) title.textContent = copy.title;
  if (description) description.textContent = copy.description;
}

function analysisSurfaceParentModeWrite(surface: HTMLElement, measureMode: MeasureMode) {
  const parent = surface.closest(".card-surface") as HTMLElement | null;
  if (!parent) return;
  parent.dataset.measureMode = measureMode;
}

function analysisTabReadFromState(state: Record<string, any>): AnalysisTab {
  return analysisTabValid(state.analysisActiveTab) ? state.analysisActiveTab : DEFAULT_ANALYSIS_TAB;
}

function analysisTabWrite(state: Record<string, any>, nextTab: AnalysisTab) {
  state.analysisActiveTab = nextTab;
}

function analysisTabButtonsBuild() {
  return Array.from(document.querySelectorAll<HTMLButtonElement>("[data-analysis-tab]"));
}

function analysisTabFromButton(button: HTMLButtonElement): AnalysisTab | null {
  return analysisTabValid(button.dataset.analysisTab) ? button.dataset.analysisTab : null;
}

function analysisTabValid(raw: unknown): raw is AnalysisTab {
  return raw === "peak_analysis" || raw === "material_properties";
}

function analysisSurfaceElementGet() {
  return document.getElementById("analysis_surface") as HTMLElement | null;
}
