import { waveformLabelResolveFromContext } from "./resonate_waveform_label.js";
import {
  noteWindowRangeBuildFromSlice,
  noteWindowSliceFindByTime,
  noteSelectionWindowRequestedFromPlotlyClick,
} from "./resonate_note_window_selection.js";
import { resolveColorHexFromRole, resolveColorRgbaFromRole } from "./resonate_color_roles.js";
import { measureModeNormalize } from "./resonate_mode_config.js";

type WaveformViewDeps = {
  state: Record<string, any>;
  setStatus: (text: string) => void;
  runResonatePipeline: (trigger: string) => Promise<void>;
  renderPeakAnalysis?: () => void;
};

let waveUpdatingShapes = false;
const TAP_CLUSTER_GAP_MS = 950;
const NOTE_CLUSTER_GAP_MS = 2600;
const TAP_CLUSTER_OUTLIER_MIN_RATIO = 0.6;
const TAP_CLUSTER_OUTLIER_MAX_RATIO = 1.8;
const FALLBACK_WINDOW_MIN_MS = 900;
const FALLBACK_WINDOW_MAX_MS = 3000;
const FALLBACK_WINDOW_RATIO = 0.22;
const RANGE_DRAG_EDGE_TOLERANCE_PX = 18;
const RANGE_DRAG_MIN_WIDTH_MS = 80;
const NOTE_EDITOR_POPOVER_ID = "wave_note_override_editor";
const NOTE_RANGE_GRIP_Y = { start: 0.02, end: 0.25 };
const PRIMARY_RANGE_GRIP_Y = { start: 0.37, end: 0.6 };
const RANGE_CENTER_GRIP_Y = { start: -0.16, end: 0.06 };

type WaveRange = { start: number; end: number };
type TapSegment = { start: number; end: number };
type TapMarkerState = "accepted" | "weak" | "rejected" | "selected";
type RangeDragMode = "move" | "resize-left" | "resize-right";
type RangeDragTarget = { rangeKind: "primary" | "note"; dragMode: RangeDragMode };
type RangeDragSession = {
  target: RangeDragTarget;
  startCursorMs: number;
  startRange: WaveRange;
};
type RangeDragContext = {
  deps: WaveformViewDeps;
  slice: any;
  onPrimaryRangeChange: (range: any) => void;
  onNoteSelectionRangeChange: (range: any) => void;
};
type NoteLabelOverrideMap = Record<number, string>;
type NotePitch = { semitone: number; octave: number };

function waveRangeFingerprint(range: WaveRange | null | undefined) {
  if (!range) return "none";
  return `${range.start}:${range.end}`;
}

function primaryRangePipelineShouldTriggerFromRangeChange(
  state: Record<string, any>,
  nextRange: WaveRange | null | undefined,
) {
  const nextFingerprint = waveRangeFingerprint(nextRange);
  if (state.lastPrimaryRangePipelineFingerprint === nextFingerprint) return false;
  state.lastPrimaryRangePipelineFingerprint = nextFingerprint;
  return true;
}

function noteRangePipelineShouldTriggerFromRangeChange(
  state: Record<string, any>,
  nextRange: WaveRange | null | undefined,
) {
  const nextFingerprint = waveRangeFingerprint(nextRange);
  if (state.lastNoteRangePipelineFingerprint === nextFingerprint) return false;
  state.lastNoteRangePipelineFingerprint = nextFingerprint;
  return true;
}

function buildSelectionShapes(range: { start: number; end: number } | null) {
  if (!range) return [];
  return [
    {
      type: "rect",
      xref: "x",
      yref: "paper",
      x0: range.start,
      x1: range.end,
      y0: 0,
      y1: 1,
      line: { color: resolveColorRgbaFromRole("wavePrimarySelection", 0.95), width: 2 },
      fillcolor: resolveColorRgbaFromRole("wavePrimarySelection", 0.1),
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.start,
      x1: range.start,
      y0: 0,
      y1: 1,
      line: { color: resolveColorRgbaFromRole("wavePrimarySelection", 0.95), width: 6 },
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.end,
      x1: range.end,
      y0: 0,
      y1: 1,
      line: { color: resolveColorRgbaFromRole("wavePrimarySelection", 0.95), width: 6 },
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.start,
      x1: range.start,
      y0: PRIMARY_RANGE_GRIP_Y.start,
      y1: PRIMARY_RANGE_GRIP_Y.end,
      layer: "above",
      line: { color: resolveColorRgbaFromRole("wavePrimarySelection", 1), width: 10 },
      name: "FFT range left grip",
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.end,
      x1: range.end,
      y0: PRIMARY_RANGE_GRIP_Y.start,
      y1: PRIMARY_RANGE_GRIP_Y.end,
      layer: "above",
      line: { color: resolveColorRgbaFromRole("wavePrimarySelection", 1), width: 10 },
      name: "FFT range right grip",
    },
    rangeCenterGripShapeBuild(
      range,
      "wavePrimarySelection",
      "FFT range center grip",
      RANGE_CENTER_GRIP_Y,
    ),
  ];
}

function buildNoteSelectionShapes(range: { start: number; end: number } | null) {
  if (!range) return [];
  return [
    {
      type: "rect",
      xref: "x",
      yref: "paper",
      x0: range.start,
      x1: range.end,
      y0: 0,
      y1: 1,
      line: { color: resolveColorRgbaFromRole("waveNoteSelection", 0.95), width: 2 },
      fillcolor: resolveColorRgbaFromRole("waveNoteSelection", 0.1),
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.start,
      x1: range.start,
      y0: 0,
      y1: 1,
      line: { color: resolveColorRgbaFromRole("waveNoteSelection", 0.95), width: 6 },
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.end,
      x1: range.end,
      y0: 0,
      y1: 1,
      line: { color: resolveColorRgbaFromRole("waveNoteSelection", 0.95), width: 6 },
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.start,
      x1: range.start,
      y0: NOTE_RANGE_GRIP_Y.start,
      y1: NOTE_RANGE_GRIP_Y.end,
      layer: "above",
      line: { color: resolveColorRgbaFromRole("waveNoteSelection", 1), width: 10 },
      name: "Note range left grip",
    },
    {
      type: "line",
      xref: "x",
      yref: "paper",
      x0: range.end,
      x1: range.end,
      y0: NOTE_RANGE_GRIP_Y.start,
      y1: NOTE_RANGE_GRIP_Y.end,
      layer: "above",
      line: { color: resolveColorRgbaFromRole("waveNoteSelection", 1), width: 10 },
      name: "Note range right grip",
    },
    rangeCenterGripShapeBuild(
      range,
      "waveNoteSelection",
      "Note range center grip",
      RANGE_CENTER_GRIP_Y,
    ),
  ];
}

function rangeCenterGripShapeBuild(
  range: WaveRange,
  colorRole: "wavePrimarySelection" | "waveNoteSelection",
  name: string,
  yRange: { start: number; end: number },
) {
  const center = (range.start + range.end) / 2;
  const halfSpan = rangeCenterGripSpanResolve(range) / 2;
  return {
    type: "rect",
    xref: "x",
    yref: "paper",
    x0: center - halfSpan,
    x1: center + halfSpan,
    y0: yRange.start,
    y1: yRange.end,
    layer: "above",
    line: { color: resolveColorRgbaFromRole(colorRole, 1), width: 1 },
    fillcolor: resolveColorRgbaFromRole(colorRole, 1),
    name,
  };
}

function rangeCenterGripSpanResolve(range: WaveRange) {
  const rangeWidth = range.end - range.start;
  const desiredSpan = Math.min(480, Math.max(90, rangeWidth * 0.25));
  return Math.min(desiredSpan, rangeWidth * 0.6);
}

function buildTapSegmentShapes(
  tapSegments: TapSegment[],
  sampleRate: number,
  selectedTapIndex: number | null,
  primaryRange: WaveRange | null,
  classifyDurationOutliers = true,
) {
  const shapes: any[] = [];
  const tapMedianDurationMs = classifyDurationOutliers
    ? tapMedianDurationMsResolve(tapSegments, sampleRate)
    : null;
  tapSegments.forEach((tap, index) => {
    const midMs = ((tap.start + tap.end) / 2 / sampleRate) * 1000;
    const markerState = tapMarkerStateResolve(tap, index, sampleRate, selectedTapIndex, primaryRange, tapMedianDurationMs);
    shapes.push({
      type: "line",
      xref: "x",
      yref: "paper",
      x0: midMs,
      x1: midMs,
      y0: 0,
      y1: 1,
      line: tapMarkerLineBuild(markerState),
      name: `Tap ${index + 1} ${markerState}`,
    });
  });
  return shapes;
}

function tapMarkerStateResolve(
  tap: TapSegment,
  index: number,
  sampleRate: number,
  selectedTapIndex: number | null,
  primaryRange: WaveRange | null,
  medianDurationMs: number | null,
): TapMarkerState {
  if (index === selectedTapIndex) return "selected";
  const range = tapRangeMsBuild(tap, sampleRate);
  if (range && primaryRange && !tapRangeMidpointWithinRange(range, primaryRange)) return "rejected";
  if (range && tapRangeWeakFromMedian(range, medianDurationMs)) return "weak";
  return "accepted";
}

function tapRangeMidpointWithinRange(tapRange: WaveRange, primaryRange: WaveRange) {
  const midMs = (tapRange.start + tapRange.end) / 2;
  return midMs >= primaryRange.start && midMs <= primaryRange.end;
}

function tapRangeWeakFromMedian(tapRange: WaveRange, medianDurationMs: number | null) {
  if (!Number.isFinite(medianDurationMs) || (medianDurationMs as number) <= 0) return false;
  const durationMs = tapRange.end - tapRange.start;
  return durationMs < (medianDurationMs as number) * TAP_CLUSTER_OUTLIER_MIN_RATIO
    || durationMs > (medianDurationMs as number) * TAP_CLUSTER_OUTLIER_MAX_RATIO;
}

function tapMarkerLineBuild(markerState: TapMarkerState) {
  if (markerState === "selected") return { color: resolveColorRgbaFromRole("wavePrimarySelection", 0.95), width: 4 };
  if (markerState === "rejected") return { color: "rgba(255, 126, 102, 0.42)", width: 1.4, dash: "dash" };
  if (markerState === "weak") return { color: resolveColorRgbaFromRole("waveTapMarker", 0.34), width: 1.4, dash: "dot" };
  return { color: resolveColorRgbaFromRole("waveTapMarker", 0.62), width: 2 };
}

function tapMedianDurationMsResolve(tapSegments: TapSegment[], sampleRate: number) {
  const durations = tapSegments
    .map((tap) => {
      const range = tapRangeMsBuild(tap, sampleRate);
      return range ? range.end - range.start : null;
    })
    .filter((duration): duration is number => Number.isFinite(duration) && duration > 0)
    .sort((left, right) => left - right);
  if (!durations.length) return null;
  const middleIndex = Math.floor(durations.length / 2);
  if (durations.length % 2 === 1) return durations[middleIndex];
  return (durations[middleIndex - 1] + durations[middleIndex]) / 2;
}

function buildNoteSliceShapes(noteSlices: Array<{ id: number; startMs: number; endMs: number }>, activeRange: { start: number; end: number } | null) {
  const shapes: any[] = [];
  noteSlices.forEach((note) => {
    const isSelected = activeRange && note.startMs >= activeRange.start && note.endMs <= activeRange.end;
    shapes.push({
      type: "rect",
      xref: "x",
      yref: "paper",
      x0: note.startMs,
      x1: note.endMs,
      y0: 0,
      y1: 1,
      fillcolor: isSelected
        ? resolveColorRgbaFromRole("wavePrimarySelection", 0.2)
        : resolveColorRgbaFromRole("fftLine", 0.12),
      line: {
        color: isSelected
          ? resolveColorRgbaFromRole("wavePrimarySelection", 0.8)
          : resolveColorRgbaFromRole("fftLine", 0.25),
        width: 1,
      },
    });
  });
  return shapes;
}

function noteLabelFromFreq(freq: number | null) {
  if (!Number.isFinite(freq)) return null;
  const FFTUtils = (window as any).FFTUtils;
  if (!FFTUtils?.freqToNoteCents) return null;
  try {
    const out = FFTUtils.freqToNoteCents(freq);
    const name = typeof out?.name === "string" ? out.name : null;
    return name;
  } catch {
    return null;
  }
}

export function noteLabelOverridesGetOrInit(state: Record<string, any>) {
  return (state.noteLabelOverrides || (state.noteLabelOverrides = {})) as NoteLabelOverrideMap;
}

export function noteLabelOverrideSet(state: Record<string, any>, noteSliceId: number, label: string) {
  const normalized = noteLabelOverrideNormalized(label);
  if (!normalized) return;
  const overrides = noteLabelOverridesGetOrInit(state);
  overrides[noteSliceId] = normalized;
}

export function noteLabelOverrideReset(state: Record<string, any>, noteSliceId: number) {
  const overrides = noteLabelOverridesGetOrInit(state);
  delete overrides[noteSliceId];
}

function noteLabelOverrideResolveFromState(state: Record<string, any>, noteSliceId: number | null | undefined) {
  if (!Number.isFinite(noteSliceId)) return null;
  const overrides = noteLabelOverridesGetOrInit(state);
  const value = overrides[noteSliceId as number];
  return typeof value === "string" && value.length ? value : null;
}

function noteLabelOverrideNormalized(rawLabel: string) {
  const compact = String(rawLabel || "").trim().replace(/\s+/g, "");
  return compact ? compact.toUpperCase() : "";
}

function resolveWaveLabelFromContext(
  f0: number | null,
  noteSlice: { id?: number; startMs?: number; endMs?: number; samples?: Float32Array; sampleRate?: number } | null,
  deps: WaveformViewDeps,
) {
  return waveformLabelResolveFromContext({
    f0,
    measureMode: deps.state.measureMode,
    modesDetected: deps.state.lastModesDetected || [],
    noteSliceSampleCount: noteSlice?.samples?.length,
    noteSliceSampleRate: noteSlice?.sampleRate,
    debugMeta: {
      noteSliceId: noteSlice?.id,
      noteSliceStartMs: noteSlice?.startMs,
      noteSliceEndMs: noteSlice?.endMs,
      measureMode: deps.state.measureMode,
    },
    noteNameResolve: (freq) => noteLabelFromFreq(freq),
  });
}

function resolveWaveLabelFromStateOrContext(
  noteSlice: { id?: number; samples?: Float32Array; sampleRate?: number },
  detectedF0: number | null,
  deps: WaveformViewDeps,
) {
  const override = noteLabelOverrideResolveFromState(deps.state, noteSlice?.id);
  if (override) return override;
  return resolveWaveLabelFromContext(detectedF0, noteSlice, deps);
}

function buildWaveAnnotations(
  noteSlices: Array<{ id: number; startMs: number; endMs: number }>,
  noteResults: Array<{ id: number; f0: number | null }>,
  deps: WaveformViewDeps,
) {
  const annotations: any[] = [];
  noteSlices.forEach((note) => {
    const result = noteResults.find((n) => n.id === note.id);
    const label = resolveWaveLabelFromStateOrContext(note as any, result?.f0 ?? null, deps);
    if (!label) return;
    const mid = (note.startMs + note.endMs) / 2;
    annotations.push({
      x: mid,
      y: 0.95,
      xref: "x",
      yref: "paper",
      text: label,
      showarrow: false,
      font: { color: "rgba(255,255,255,0.7)", size: 11 },
      noteSliceId: note.id,
    });
  });
  return annotations;
}

export function buildWaveShapes(
  sampleRate: number,
  primaryRange: { start: number; end: number } | null,
  noteSelectionRange: { start: number; end: number } | null,
  tapSegments: TapSegment[] | null | undefined,
  noteSlices: Array<{ id: number; startMs: number; endMs: number }> | null | undefined,
  measureMode: unknown,
  selectedTapIndex?: unknown,
) {
  const shapes: any[] = [];
  const activeTapIndex = selectedTapIndexForMeasureMode(measureMode, selectedTapIndex);
  const peakAnalysisActive = measureModeNormalize(measureMode) === "peak_analysis";
  const visiblePrimaryRange = peakAnalysisActive ? null : primaryRange;
  shapes.push(...buildNoteSliceShapes(noteSlices || [], visiblePrimaryRange));
  shapes.push(...buildTapSegmentShapes(
    tapSegments || [],
    sampleRate,
    activeTapIndex,
    null,
    !peakAnalysisActive,
  ));
  if (noteSelectionRangeVisibleForMeasureMode(measureMode)) {
    shapes.push(...buildNoteSelectionShapes(noteSelectionRange));
  }
  shapes.push(...buildSelectionShapes(visiblePrimaryRange));
  return shapes;
}

function selectedTapIndexForMeasureMode(measureMode: unknown, selectedTapIndex: unknown) {
  if (measureModeNormalize(measureMode) !== "peak_analysis") return null;
  const index = Number(selectedTapIndex);
  return Number.isInteger(index) && index >= 0 ? index : 0;
}

export function noteSelectionRangeVisibleForMeasureMode(measureMode: unknown) {
  return measureModeNormalize(measureMode) === "played_note";
}

export function tapSegmentAtTimeResolve(
  tapSegments: TapSegment[] | null | undefined,
  sampleRate: number,
  timeMs: number,
) {
  const taps = Array.isArray(tapSegments) ? tapSegments : [];
  if (!Number.isFinite(sampleRate) || sampleRate <= 0 || !Number.isFinite(timeMs)) return null;
  for (let index = 0; index < taps.length; index += 1) {
    const range = tapRangeMsBuild(taps[index], sampleRate);
    if (!range) continue;
    if (timeMs >= range.start && timeMs <= range.end) return { tap: taps[index], index, range };
  }
  return null;
}

function tapRangeMsBuild(tap: TapSegment, sampleRate: number) {
  const start = Number(tap.start);
  const end = Number(tap.end);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return null;
  return {
    start: (start / sampleRate) * 1000,
    end: (end / sampleRate) * 1000,
  };
}

function peakAnalysisSelectedTapIndexWrite(state: Record<string, any>, tapIndex: number) {
  if (measureModeNormalize(state.measureMode) !== "peak_analysis") return;
  state.peakAnalysisSelectedTapIndex = tapIndex;
}

function peakAnalysisTapSelectionApply(deps: WaveformViewDeps, slice: any, tapIndex: number) {
  peakAnalysisSelectedTapIndexWrite(deps.state, tapIndex);
  renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
  deps.renderPeakAnalysis?.();
}

function renderWaveSelection(
  primaryRange: { start: number; end: number } | null,
  noteSelectionRange: { start: number; end: number } | null,
  deps: WaveformViewDeps,
  slice: any,
) {
  const plot = document.getElementById("plot_waveform");
  if (!plot) return;
  const Plotly = (window as any).Plotly;
  if (!Plotly) return;
  const shapes = buildWaveShapes(
    slice.sampleRate,
    primaryRange,
    noteSelectionRange,
    deps.state.tapSegments,
    deps.state.noteSlices,
    deps.state.measureMode,
    deps.state.peakAnalysisSelectedTapIndex,
  );

  waveUpdatingShapes = true;
  Promise.resolve(Plotly.relayout(plot, { shapes })).finally(() => {
    waveUpdatingShapes = false;
  });
}

function renderWaveAnnotations(deps: WaveformViewDeps, slice: any) {
  const plot = document.getElementById("plot_waveform");
  if (!plot) return;
  const Plotly = (window as any).Plotly;
  if (!Plotly) return;
  const annotations = buildWaveAnnotations(deps.state.noteSlices || [], deps.state.noteResults || [], deps);
  void Plotly.relayout(plot, { annotations });
}

function makeWaveNavigatorPlot(
  slice: any,
  deps: WaveformViewDeps,
  onPrimaryRangeChange: (range: any) => void,
  onNoteSelectionRangeChange: (range: any) => void,
) {
  const plot = document.getElementById("plot_waveform");
  if (!plot) return;
  const Plotly = (window as any).Plotly;
  if (!Plotly) return;

  markWaveformSurfaceReadyFromPlot(plot);
  const absWave = Array.from(slice.wave, (v: number) => Math.abs(v));
  const timeMs = Array.isArray(slice.timeMs)
    ? slice.timeMs
    : Array.from({ length: absWave.length }, (_, i) => (i / slice.sampleRate) * 1000);
  const maxAbs = absWave.reduce((max, v) => (Number.isFinite(v) && v > max ? v : max), 0);
  const yMax = maxAbs > 0 ? maxAbs * 1.05 : 1;
  const plotlyWaveToolsEnabled = plotlyWaveToolsEnabledResolve();
  deps.state.waveRenderDebug = { maxAbs, yMax };
  const trace = {
    x: timeMs,
    y: absWave,
    type: "scatter",
    mode: "lines",
    fill: "tozeroy",
    fillcolor: resolveColorRgbaFromRole("fftLine", 0.16),
    line: { color: resolveColorHexFromRole("fftLine"), width: 1.5 },
    hovertemplate: "%{x:.0f} ms<extra></extra>",
  };

  const layout = {
    height: 80,
    margin: { l: 40, r: 10, t: 6, b: 26 },
    paper_bgcolor: "transparent",
    plot_bgcolor: "transparent",
    showlegend: false,
    xaxis: {
      showgrid: false,
      zeroline: false,
      color: "rgba(255,255,255,0.45)",
      title: "",
      fixedrange: !plotlyWaveToolsEnabled,
    },
    yaxis: {
      showgrid: false,
      zeroline: false,
      showticklabels: false,
      fixedrange: true,
    },
    shapes: buildWaveShapes(
      slice.sampleRate,
      deps.state.viewRangeMs || null,
      deps.state.noteSelectionRangeMs || null,
      deps.state.tapSegments,
      deps.state.noteSlices,
      deps.state.measureMode,
      deps.state.peakAnalysisSelectedTapIndex,
    ),
    annotations: buildWaveAnnotations(deps.state.noteSlices || [], deps.state.noteResults || [], deps),
  };

  Plotly.newPlot(plot, [trace], layout, {
    displayModeBar: plotlyWaveToolsEnabled,
    displaylogo: false,
    responsive: true,
    modeBarButtonsToRemove: plotlyWaveToolsEnabled
      ? ["select2d", "lasso2d"]
      : ["zoom2d", "pan2d", "select2d", "lasso2d", "zoomIn2d", "zoomOut2d", "autoScale2d"],
  });

  if (typeof (plot as any).removeAllListeners === "function") {
    (plot as any).removeAllListeners("plotly_relayout");
    (plot as any).removeAllListeners("plotly_click");
    (plot as any).removeAllListeners("plotly_clickannotation");
  }
  bindWaveNoteOverrideDismissInteractions(plot as HTMLElement);
  bindWaveNoteOverrideModifierClickInteractions(plot as HTMLElement, deps, slice);
  bindPeakAnalysisTapPointerInteractions(plot as HTMLElement, deps, slice);
  (plot as any).on("plotly_click", (ev: any) => {
    if ((plot as any).__resonateSuppressClick) {
      (plot as any).__resonateSuppressClick = false;
      return;
    }
    const pt = ev?.points?.[0];
    if (!pt) return;
    const x = pt.x as number;
    if (!Number.isFinite(x)) return;
    if (measureModeNormalize(deps.state.measureMode) === "peak_analysis") {
      const tapHit = tapSegmentAtTimeResolve(deps.state.tapSegments, slice.sampleRate, x);
      if (!tapHit) return;
      peakAnalysisTapSelectionApply(deps, slice, tapHit.index);
      return;
    }
    const note = noteWindowSliceFindByTime(deps.state.noteSlices || [], x);
    if (note) {
      if (waveNoteOverrideRequestedFromClickEvent(ev?.event)) {
        openWaveNoteOverrideEditorFromSlice(note.id, x, deps, slice);
        return;
      }
      const range = noteWindowRangeBuildFromSlice(note);
      if (noteSelectionWindowRequestedFromPlotlyClick(ev)) {
        deps.state.noteSelectionRangeMs = range;
        renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
        onNoteSelectionRangeChange?.(range);
        return;
      }
      deps.state.viewRangeMs = range;
      renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
      onPrimaryRangeChange?.(range);
      return;
    }
    const tapHit = tapSegmentAtTimeResolve(deps.state.tapSegments, slice.sampleRate, x);
    if (!tapHit) return;
    peakAnalysisSelectedTapIndexWrite(deps.state, tapHit.index);
    const range = tapHit.range;
    deps.state.viewRangeMs = range;
    renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
    onPrimaryRangeChange?.(range);
  });
  (plot as any).on("plotly_clickannotation", (ev: any) => {
    const anchorMs = Number(ev?.annotation?.x);
    if (!Number.isFinite(anchorMs)) return;
    const note = noteWindowSliceFindByTime(deps.state.noteSlices || [], anchorMs);
    if (!note) return;
    openWaveNoteOverrideEditorFromSlice(note.id, anchorMs, deps, slice);
  });
  (plot as any).on("plotly_relayout", (ev: any) => {
    if (waveUpdatingShapes) return;
    if (measureModeNormalize(deps.state.measureMode) === "peak_analysis") return;
    const range0 = ev["xaxis.range[0]"];
    const range1 = ev["xaxis.range[1]"];
    const auto = ev["xaxis.autorange"];
    if (auto || range0 === undefined || range1 === undefined) {
      if ((plot as any).__resonateShiftDragActive) {
        deps.state.noteSelectionRangeMs = null;
        renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
        onNoteSelectionRangeChange?.(null);
      } else {
        deps.state.viewRangeMs = null;
        renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
        onPrimaryRangeChange?.(null);
      }
      return;
    }
    const start = Number(range0);
    const end = Number(range1);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return;
    const range = { start, end };
    if ((plot as any).__resonateShiftDragActive) {
      deps.state.noteSelectionRangeMs = range;
      renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
      onNoteSelectionRangeChange?.(range);
    } else {
      deps.state.viewRangeMs = range;
      renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
      onPrimaryRangeChange?.(range);
    }
  });

  renderWaveSelection(deps.state.viewRangeMs || null, deps.state.noteSelectionRangeMs || null, deps, slice);
  bindNoteSelectionResizeModifierTracking(plot as HTMLElement);
  bindRangeDirectDragInteractions(plot as HTMLElement, deps, slice, onPrimaryRangeChange, onNoteSelectionRangeChange);
}

function openWaveNoteOverrideEditorFromSlice(
  noteSliceId: number,
  anchorMs: number,
  deps: WaveformViewDeps,
  slice: any,
) {
  const noteSlice = (deps.state.noteSlices || []).find((entry: { id: number }) => entry.id === noteSliceId);
  if (!noteSlice) return;
  const detectedLabel = waveDetectedLabelResolveForNoteSlice(noteSlice, deps);
  if (!detectedLabel || detectedLabel === "Tap") {
    deps.setStatus("Tap labels are automatic; note override is available on note slices.");
    return;
  }
  const plot = document.getElementById("plot_waveform");
  if (!(plot instanceof HTMLElement)) return;
  const editor = waveNoteOverrideEditorGetOrCreate(plot);
  const header = editor.querySelector("[data-wave-note-detected]") as HTMLElement | null;
  const quick = editor.querySelector("[data-wave-note-quick]") as HTMLElement | null;
  const input = editor.querySelector("[data-wave-note-input]") as HTMLInputElement | null;
  const applyBtn = editor.querySelector("[data-wave-note-apply]") as HTMLButtonElement | null;
  const clearBtn = editor.querySelector("[data-wave-note-clear]") as HTMLButtonElement | null;
  const closeBtn = editor.querySelector("[data-wave-note-close]") as HTMLButtonElement | null;
  if (!header || !quick || !input || !applyBtn || !clearBtn || !closeBtn) return;
  const currentOverride = noteLabelOverrideResolveFromState(deps.state, noteSliceId);
  header.textContent = `Detected: ${detectedLabel}`;
  input.value = currentOverride || detectedLabel;
  waveNoteQuickChoicesRender(quick, detectedLabel, input);
  const apply = () => {
    const normalized = noteLabelOverrideNormalized(input.value);
    if (normalized) noteLabelOverrideSet(deps.state, noteSliceId, normalized);
    else noteLabelOverrideReset(deps.state, noteSliceId);
    renderWaveAnnotations(deps, slice);
    waveNoteOverrideEditorHide(plot);
  };
  const clear = () => {
    noteLabelOverrideReset(deps.state, noteSliceId);
    renderWaveAnnotations(deps, slice);
    waveNoteOverrideEditorHide(plot);
  };
  applyBtn.onclick = apply;
  clearBtn.onclick = clear;
  closeBtn.onclick = () => waveNoteOverrideEditorHide(plot);
  input.onkeydown = (event: KeyboardEvent) => {
    if (event.key === "Enter") {
      event.preventDefault();
      apply();
      return;
    }
    if (event.key === "Escape") {
      event.preventDefault();
      waveNoteOverrideEditorHide(plot);
    }
  };
  waveNoteOverrideEditorPosition(plot, editor, anchorMs);
  editor.hidden = false;
  input.focus();
  input.select();
}

function waveDetectedLabelResolveForNoteSlice(noteSlice: any, deps: WaveformViewDeps) {
  const result = (deps.state.noteResults || []).find((entry: { id: number }) => entry.id === noteSlice.id);
  return resolveWaveLabelFromContext(result?.f0 ?? null, noteSlice, deps);
}

function waveNoteOverrideEditorGetOrCreate(plot: HTMLElement) {
  const existing = document.getElementById(NOTE_EDITOR_POPOVER_ID) as HTMLElement | null;
  if (existing) return existing;
  const host = plot.closest(".wave-surface") || plot.parentElement || plot;
  const editor = document.createElement("div");
  editor.id = NOTE_EDITOR_POPOVER_ID;
  editor.className = "wave-note-override-popover";
  editor.hidden = true;
  editor.innerHTML = [
    '<div class="wave-note-override-header">',
    '  <span data-wave-note-detected>Detected:</span>',
    '  <button type="button" class="ghost-btn btn-small" data-wave-note-close>Close</button>',
    "</div>",
    '<div class="wave-note-override-row" data-wave-note-quick></div>',
    '<div class="wave-note-override-row">',
    '  <input type="text" class="wave-note-override-input" data-wave-note-input placeholder="Type note (e.g. E4)" />',
    "</div>",
    '<div class="wave-note-override-actions">',
    '  <button type="button" class="ghost-btn btn-small" data-wave-note-clear>Clear</button>',
    '  <button type="button" class="ghost-btn btn-small" data-wave-note-apply>Apply</button>',
    "</div>",
  ].join("");
  host.appendChild(editor);
  return editor;
}

function waveNoteOverrideEditorHide(plot: HTMLElement) {
  const editor = document.getElementById(NOTE_EDITOR_POPOVER_ID) as HTMLElement | null;
  if (!editor) return;
  if (!plot.closest(".wave-surface")?.contains(editor)) return;
  editor.hidden = true;
}

function bindWaveNoteOverrideDismissInteractions(plot: HTMLElement) {
  const anyPlot = plot as any;
  if (anyPlot.__resonateWaveNoteOverrideDismissBound) return;
  const onPointerDown = (event: MouseEvent) => {
    const editor = document.getElementById(NOTE_EDITOR_POPOVER_ID) as HTMLElement | null;
    if (!editor || editor.hidden) return;
    const target = event.target as Node | null;
    if (!target) return;
    if (editor.contains(target)) return;
    if (plot.contains(target)) return;
    waveNoteOverrideEditorHide(plot);
  };
  document.addEventListener("mousedown", onPointerDown);
  anyPlot.__resonateWaveNoteOverrideDismissBound = true;
}

function bindWaveNoteOverrideModifierClickInteractions(plot: HTMLElement, deps: WaveformViewDeps, slice: any) {
  const anyPlot = plot as any;
  if (anyPlot.__resonateWaveNoteOverrideModifierClickBound) return;
  const onMouseDown = (event: MouseEvent) => {
    if (!waveNoteOverrideRequestedFromClickEvent(event)) return;
    const cursorMs = waveformMsAtPointerResolve(plot, event);
    if (!Number.isFinite(cursorMs)) return;
    const note = noteWindowSliceFindByTime(deps.state.noteSlices || [], cursorMs);
    if (!note) return;
    anyPlot.__resonateSuppressClick = true;
    event.preventDefault();
    event.stopPropagation();
    openWaveNoteOverrideEditorFromSlice(note.id, cursorMs, deps, slice);
  };
  plot.addEventListener("mousedown", onMouseDown);
  anyPlot.__resonateWaveNoteOverrideModifierClickBound = true;
}

function bindPeakAnalysisTapPointerInteractions(plot: HTMLElement, deps: WaveformViewDeps, slice: any) {
  const anyPlot = plot as any;
  anyPlot.__resonatePeakAnalysisTapPointerDeps = deps;
  anyPlot.__resonatePeakAnalysisTapPointerSlice = slice;
  if (anyPlot.__resonatePeakAnalysisTapPointerBound) return;
  const onMouseDown = (event: MouseEvent) => {
    const activeDeps = anyPlot.__resonatePeakAnalysisTapPointerDeps as WaveformViewDeps;
    const activeSlice = anyPlot.__resonatePeakAnalysisTapPointerSlice;
    if (event.button !== 0 || measureModeNormalize(activeDeps.state.measureMode) !== "peak_analysis") return;
    const cursorMs = waveformMsAtPointerResolve(plot, event);
    const tapHit = tapSegmentAtTimeResolve(activeDeps.state.tapSegments, activeSlice.sampleRate, cursorMs);
    if (!tapHit) return;
    anyPlot.__resonateSuppressClick = true;
    event.preventDefault();
    event.stopPropagation();
    peakAnalysisTapSelectionApply(activeDeps, activeSlice, tapHit.index);
  };
  plot.addEventListener("mousedown", onMouseDown, true);
  anyPlot.__resonatePeakAnalysisTapPointerBound = true;
}

function waveNoteOverrideEditorPosition(plot: HTMLElement, editor: HTMLElement, anchorMs: number) {
  const axis = waveformAxisRangeResolve(plot);
  if (!axis || !Number.isFinite(anchorMs)) {
    editor.style.left = "24px";
    editor.style.top = "16px";
    return;
  }
  const ratio = clamp01((anchorMs - axis.min) / (axis.max - axis.min));
  const anchorPx = axis.leftPx + ratio * axis.widthPx;
  const leftPx = Math.max(12, Math.min(axis.leftPx + axis.widthPx - 280, anchorPx - 130));
  editor.style.left = `${leftPx}px`;
  editor.style.top = "16px";
}

function waveNoteQuickChoicesRender(host: HTMLElement, detectedLabel: string, input: HTMLInputElement) {
  host.innerHTML = "";
  const candidates = waveNoteQuickChoiceLabelsResolve(detectedLabel);
  candidates.forEach((label) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "ghost-btn btn-small";
    button.textContent = label;
    button.onclick = () => {
      input.value = label;
      input.focus();
      input.select();
    };
    host.appendChild(button);
  });
}

function markWaveformSurfaceReadyFromPlot(plot: HTMLElement) {
  const surface = plot.closest("#wave_nav");
  if (!surface) return;
  surface.setAttribute("data-waveform-ready", "true");
}

export function waveNoteOverrideRequestedFromClickEvent(event: { altKey?: boolean; metaKey?: boolean } | null | undefined) {
  if (!event) return false;
  return Boolean(event.altKey || event.metaKey);
}

export function waveNoteQuickChoiceLabelsResolve(detectedLabel: string) {
  const out: string[] = [];
  const previous = waveNoteLabelTransposeBySemitone(detectedLabel, -1);
  if (previous) out.push(previous);
  out.push(noteLabelOverrideNormalized(detectedLabel));
  const next = waveNoteLabelTransposeBySemitone(detectedLabel, 1);
  if (next) out.push(next);
  return Array.from(new Set(out));
}

function waveNoteLabelTransposeBySemitone(noteLabel: string, semitoneDelta: number) {
  const pitch = waveNotePitchParse(noteLabel);
  if (!pitch) return null;
  const absolute = pitch.octave * 12 + pitch.semitone + semitoneDelta;
  const nextSemitone = ((absolute % 12) + 12) % 12;
  const nextOctave = Math.floor((absolute - nextSemitone) / 12);
  return `${waveSemitoneNameResolve(nextSemitone)}${nextOctave}`;
}

function waveNotePitchParse(noteLabel: string): NotePitch | null {
  const match = /^([A-Ga-g])([#b]?)(-?\d+)$/.exec(String(noteLabel || "").trim());
  if (!match) return null;
  const letter = match[1].toUpperCase();
  const accidental = match[2];
  const octave = Number(match[3]);
  if (!Number.isFinite(octave)) return null;
  const base = waveNaturalSemitoneResolve(letter);
  if (base === null) return null;
  const accidentalOffset = accidental === "#" ? 1 : accidental === "b" ? -1 : 0;
  const semitone = ((base + accidentalOffset) % 12 + 12) % 12;
  return { semitone, octave };
}

function waveNaturalSemitoneResolve(letter: string) {
  if (letter === "C") return 0;
  if (letter === "D") return 2;
  if (letter === "E") return 4;
  if (letter === "F") return 5;
  if (letter === "G") return 7;
  if (letter === "A") return 9;
  if (letter === "B") return 11;
  return null;
}

function waveSemitoneNameResolve(semitone: number) {
  const names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  return names[((semitone % 12) + 12) % 12];
}

export function renderWaveform(slice: any, deps: WaveformViewDeps) {
  waveformAutoRangesApplyToState(slice, deps.state);
  const handlers = waveformRangeHandlersBuild(deps);
  makeWaveNavigatorPlot(slice, deps, handlers.onPrimaryRangeChange, handlers.onNoteSelectionRangeChange);
}

export function waveformAutoRangesApplyToState(slice: any, state: Record<string, any>) {
  const autoPrimaryRange = primaryRangeAutoSelectFromState(slice, state);
  if (autoPrimaryRange) state.viewRangeMs = autoPrimaryRange;
  const autoNoteSelectionRange = noteSelectionRangeAutoSelectFromState(slice, state);
  if (autoNoteSelectionRange) state.noteSelectionRangeMs = autoNoteSelectionRange;
}

export function noteSelectionRangeAutoSelectFromState(slice: any, state: Record<string, any>) {
  if (noteSelectionRangeShouldPreserveExistingFromState(slice, state)) return null;
  const noteSlices = noteSlicesAfterPrimaryRangeResolve(noteSlicesAutoSelectionCandidatesResolve(state), state.viewRangeMs || null);
  if (!noteSlices.length) return fallbackRangeOnRightFromDuration(waveDurationMsResolve(state, slice));
  const range = largestContiguousRangeClusterBuild(
    noteSlices.map((entry: { startMs: number; endMs: number }) => ({ start: entry.startMs, end: entry.endMs })),
    NOTE_CLUSTER_GAP_MS,
  );
  return range || fallbackRangeOnRightFromDuration(waveDurationMsResolve(state, slice));
}

function noteSelectionRangeShouldPreserveExistingFromState(slice: any, state: Record<string, any>) {
  const existingRange = state.noteSelectionRangeMs;
  if (!existingRange) return false;
  const fallbackRange = fallbackRangeOnRightFromDuration(waveDurationMsResolve(state, slice));
  const existingLooksLikeFallback = rangeMatchesExactly(existingRange, fallbackRange);
  if (!existingLooksLikeFallback) return true;
  const noteSlices = noteSlicesAutoSelectionCandidatesResolve(state);
  return !noteSlices.length;
}

function noteSlicesAutoSelectionCandidatesResolve(state: Record<string, any>) {
  const noteSlices = Array.isArray(state.noteSlices) ? state.noteSlices : [];
  if (!noteSlices.length) return [];
  const noteResults = Array.isArray(state.noteResults) ? state.noteResults : [];
  if (!noteResults.length) return noteSlices;
  const noteOnlySlices = noteSlices.filter((noteSlice) => !noteSliceClassifiedAsTap(noteSlice, noteResults, state));
  return noteOnlySlices.length ? noteOnlySlices : noteSlices;
}

function noteSlicesAfterPrimaryRangeResolve(
  noteSlices: Array<{ startMs: number; endMs: number }>,
  primaryRange: { start: number; end: number } | null,
) {
  if (!primaryRange || !Number.isFinite(primaryRange.end)) return noteSlices;
  const slicesAfterPrimaryRange = noteSlices.filter((slice) => Number(slice.startMs) >= Number(primaryRange.end));
  return slicesAfterPrimaryRange.length ? slicesAfterPrimaryRange : noteSlices;
}

function noteSliceClassifiedAsTap(
  noteSlice: { id?: number; samples?: Float32Array; sampleRate?: number },
  noteResults: Array<{ id: number; f0: number | null }>,
  state: Record<string, any>,
) {
  const result = noteResults.find((entry) => entry.id === noteSlice.id);
  const label = waveformLabelResolveFromContext({
    f0: result?.f0 ?? null,
    measureMode: state.measureMode,
    modesDetected: state.lastModesDetected || [],
    noteSliceSampleCount: noteSlice?.samples?.length,
    noteSliceSampleRate: noteSlice?.sampleRate,
    noteNameResolve: () => "Note",
  });
  return label === "Tap";
}

export function primaryRangeAutoSelectFromState(slice: any, state: Record<string, any>) {
  if (state.viewRangeMs) return null;
  const taps = Array.isArray(state.tapSegments) ? state.tapSegments : [];
  if (!taps.length) return fallbackRangeOnLeftFromDuration(waveDurationMsResolve(state, slice));
  const ranges = taps
    .map((tap: { start: number; end: number }) => ({
      start: (tap.start / slice.sampleRate) * 1000,
      end: (tap.end / slice.sampleRate) * 1000,
    }))
    .filter((range: { start: number; end: number }) => Number.isFinite(range.start) && Number.isFinite(range.end) && range.end > range.start);
  const bestCluster = contiguousRangeClusterBestBuild(ranges, TAP_CLUSTER_GAP_MS, { preferCount: true });
  const normalizedRange = rangeClusterNormalizeByMedianDuration(bestCluster);
  return normalizedRange || fallbackRangeOnLeftFromDuration(waveDurationMsResolve(state, slice));
}

function waveDurationMsResolve(state: Record<string, any>, slice?: any) {
  const fromSlice = Number(slice?.timeMs?.[slice.timeMs.length - 1]);
  if (Number.isFinite(fromSlice) && fromSlice > 0) return fromSlice;
  const fromCurrentWave = Number(state?.currentWave?.fullLengthMs);
  if (Number.isFinite(fromCurrentWave) && fromCurrentWave > 0) return fromCurrentWave;
  const fromState = Number(state?.endMs);
  if (Number.isFinite(fromState) && fromState > 0) return fromState;
  return 5000;
}

function fallbackWindowMsResolve(durationMs: number) {
  const scaled = durationMs * FALLBACK_WINDOW_RATIO;
  return Math.max(FALLBACK_WINDOW_MIN_MS, Math.min(FALLBACK_WINDOW_MAX_MS, scaled));
}

function fallbackRangeOnLeftFromDuration(durationMs: number) {
  const windowMs = fallbackWindowMsResolve(durationMs);
  const end = Math.min(durationMs, windowMs);
  return { start: 0, end };
}

function fallbackRangeOnRightFromDuration(durationMs: number) {
  const windowMs = fallbackWindowMsResolve(durationMs);
  const start = Math.max(0, durationMs - windowMs);
  return { start, end: Math.max(start, durationMs) };
}

function largestContiguousRangeClusterBuild(
  ranges: Array<{ start: number; end: number }>,
  gapMs: number,
  options: { preferCount?: boolean } = {},
) {
  const bestCluster = contiguousRangeClusterBestBuild(ranges, gapMs, options);
  if (!bestCluster) return null;
  return { start: bestCluster.start, end: bestCluster.end };
}

function contiguousRangeClusterBestBuild(
  ranges: Array<{ start: number; end: number }>,
  gapMs: number,
  options: { preferCount?: boolean } = {},
) {
  if (!ranges.length) return null;
  const sorted = ranges
    .slice()
    .sort((left, right) => left.start - right.start || left.end - right.end);
  const clusters = contiguousRangeClustersBuildFromSortedRanges(sorted, gapMs);
  return clusters.reduce((best, cluster) => {
    if (!best) return cluster;
    if (options.preferCount) {
      const bestCount = (best as any).ranges?.length ?? 0;
      const clusterCount = (cluster as any).ranges?.length ?? 0;
      if (clusterCount > bestCount) return cluster;
      if (clusterCount < bestCount) return best;
    }
    const bestWidth = best.end - best.start;
    const currentWidth = cluster.end - cluster.start;
    if (currentWidth > bestWidth) return cluster;
    if (currentWidth === bestWidth && cluster.start < best.start) return cluster;
    return best;
  }, null as ({ start: number; end: number; ranges?: Array<{ start: number; end: number }> } | null));
}

function contiguousRangeClustersBuildFromSortedRanges(
  sortedRanges: Array<{ start: number; end: number }>,
  gapMs: number,
) {
  const clusters: Array<{ start: number; end: number; ranges: Array<{ start: number; end: number }> }> = [];
  sortedRanges.forEach((range) => {
    const current = clusters[clusters.length - 1];
    if (!current || range.start - current.end > gapMs) {
      clusters.push({ ...range, ranges: [{ ...range }] });
      return;
    }
    current.end = Math.max(current.end, range.end);
    current.ranges.push({ ...range });
  });
  return clusters;
}

function rangeClusterNormalizeByMedianDuration(range: ({ start: number; end: number; ranges?: Array<{ start: number; end: number }> } | null)) {
  if (!range?.ranges?.length) return range ? { start: range.start, end: range.end } : null;
  const durations = range.ranges
    .map((entry) => rangeDurationMs(entry))
    .filter((duration) => Number.isFinite(duration) && duration > 0)
    .sort((left, right) => left - right);
  if (!durations.length) return { start: range.start, end: range.end };
  const median = durations[Math.floor(durations.length / 2)];
  const minDuration = median * TAP_CLUSTER_OUTLIER_MIN_RATIO;
  const maxDuration = median * TAP_CLUSTER_OUTLIER_MAX_RATIO;
  const normalized = range.ranges.filter((entry) => {
    const duration = rangeDurationMs(entry);
    return duration >= minDuration && duration <= maxDuration;
  });
  if (!normalized.length) return { start: range.start, end: range.end };
  return { start: normalized[0].start, end: normalized[normalized.length - 1].end };
}

function rangeDurationMs(range: { start: number; end: number }) {
  return range.end - range.start;
}

function bindNoteSelectionResizeModifierTracking(plot: HTMLElement) {
  const anyPlot = plot as any;
  if (anyPlot.__resonateShiftDragBound) return;
  const onPointerDown = (event: MouseEvent) => {
    anyPlot.__resonateShiftDragActive = Boolean(event.shiftKey);
  };
  const onPointerUp = () => {
    anyPlot.__resonateShiftDragActive = false;
  };
  plot.addEventListener("mousedown", onPointerDown);
  window.addEventListener("mouseup", onPointerUp);
  anyPlot.__resonateShiftDragBound = true;
  anyPlot.__resonateShiftDragActive = false;
}

function bindRangeDirectDragInteractions(
  plot: HTMLElement,
  deps: WaveformViewDeps,
  slice: any,
  onPrimaryRangeChange: (range: any) => void,
  onNoteSelectionRangeChange: (range: any) => void,
) {
  const anyPlot = plot as any;
  anyPlot.__resonateRangeDragContext = {
    deps,
    slice,
    onPrimaryRangeChange,
    onNoteSelectionRangeChange,
  } as RangeDragContext;
  if (anyPlot.__resonateRangeDragBound) return;
  const dragContextRead = () => anyPlot.__resonateRangeDragContext as RangeDragContext;
  const onPointerDown = (event: MouseEvent) => {
    const current = dragContextRead();
    if (measureModeNormalize(current.deps.state.measureMode) === "peak_analysis") return;
    if (plotlyWaveToolsEnabledResolve()) return;
    if (event.button !== 0) return;
    const cursorMs = waveformMsAtPointerResolve(plot, event);
    if (!Number.isFinite(cursorMs)) return;
    const axis = waveformAxisRangeResolve(plot);
    if (!axis) return;
    const size = (plot as any)._fullLayout?._size;
    const heightPx = Number(size?.h);
    const topPx = Number(size?.t);
    const rect = plot.getBoundingClientRect();
    const relativeY = event.clientY - rect.top - topPx;
    const paperY = waveformNavigatorPaperYResolve(relativeY, heightPx);
    const noteRange = current.deps.state.noteSelectionRangeMs;
    const edgeToleranceMs = ((axis.max - axis.min) / axis.widthPx) * RANGE_DRAG_EDGE_TOLERANCE_PX;
    const noteGripEdgeSelected = Boolean(
      noteRange
      && (Math.abs(cursorMs - noteRange.start) <= edgeToleranceMs || Math.abs(cursorMs - noteRange.end) <= edgeToleranceMs),
    );
    const noteGripTrackSelected = Boolean(
      noteSelectionRangeVisibleForMeasureMode(current.deps.state.measureMode)
      && noteGripEdgeSelected
      && Number.isFinite(heightPx)
      && Number.isFinite(topPx)
      && paperY >= NOTE_RANGE_GRIP_Y.start - 0.05
      && paperY <= NOTE_RANGE_GRIP_Y.end + 0.05,
    );
    const noteCenterGripSelected = Boolean(
      noteSelectionRangeVisibleForMeasureMode(current.deps.state.measureMode)
      && rangeCenterGripContainsPointer(noteRange, cursorMs, paperY, RANGE_CENTER_GRIP_Y),
    );
    const primaryCenterGripSelected = rangeCenterGripContainsPointer(
      current.deps.state.viewRangeMs || null,
      cursorMs,
      paperY,
      RANGE_CENTER_GRIP_Y,
    );
    const gripTarget = rangeGripDragTargetResolve(noteCenterGripSelected, primaryCenterGripSelected);
    const target = rangeDragTargetResolve(
      cursorMs,
      axis.min,
      axis.max,
      axis.widthPx,
      current.deps.state.viewRangeMs || null,
      current.deps.state.noteSelectionRangeMs || null,
      event.shiftKey || noteGripTrackSelected,
    );
    const resolvedTarget = gripTarget || target;
    if (!resolvedTarget) return;
    const activeRange = resolvedTarget.rangeKind === "note"
      ? current.deps.state.noteSelectionRangeMs || null
      : current.deps.state.viewRangeMs || null;
    if (!activeRange) return;
    anyPlot.__resonateRangeDrag = {
      target: resolvedTarget,
      startCursorMs: cursorMs,
      startRange: { start: activeRange.start, end: activeRange.end },
    } as RangeDragSession;
    anyPlot.__resonateSuppressClick = true;
    event.preventDefault();
  };
  const onPointerMove = (event: MouseEvent) => {
    const session = anyPlot.__resonateRangeDrag as RangeDragSession | undefined;
    if (!session) return;
    const current = dragContextRead();
    const cursorMs = waveformMsAtPointerResolve(plot, event);
    if (!Number.isFinite(cursorMs)) return;
    const axis = waveformAxisRangeResolve(plot);
    if (!axis) return;
    const nextRange = rangeDragApply(
      session.startRange,
      session.startCursorMs,
      cursorMs,
      session.target.dragMode,
      axis.min,
      axis.max,
    );
    if (!nextRange) return;
    if (session.target.rangeKind === "note") {
      current.deps.state.noteSelectionRangeMs = nextRange;
    } else {
      current.deps.state.viewRangeMs = nextRange;
    }
    renderWaveSelection(
      current.deps.state.viewRangeMs || null,
      current.deps.state.noteSelectionRangeMs || null,
      current.deps,
      current.slice,
    );
  };
  const onPointerUp = () => {
    const session = anyPlot.__resonateRangeDrag as RangeDragSession | undefined;
    if (!session) return;
    const current = dragContextRead();
    const range = session.target.rangeKind === "note"
      ? current.deps.state.noteSelectionRangeMs || null
      : current.deps.state.viewRangeMs || null;
    if (session.target.rangeKind === "note") {
      current.onNoteSelectionRangeChange(range);
    } else {
      current.onPrimaryRangeChange(range);
    }
    anyPlot.__resonateRangeDrag = null;
  };
  plot.addEventListener("mousedown", onPointerDown);
  window.addEventListener("mousemove", onPointerMove);
  window.addEventListener("mouseup", onPointerUp);
  anyPlot.__resonateRangeDragBound = true;
  anyPlot.__resonateRangeDrag = null;
}

function rangeCenterGripContainsPointer(
  range: WaveRange | null,
  cursorMs: number,
  paperY: number,
  yRange: { start: number; end: number },
) {
  if (!range || !Number.isFinite(paperY)) return false;
  const center = (range.start + range.end) / 2;
  const halfSpan = rangeCenterGripSpanResolve(range) / 2;
  const withinX = cursorMs >= center - halfSpan && cursorMs <= center + halfSpan;
  const withinY = paperY >= yRange.start && paperY <= yRange.end;
  return withinX && withinY;
}

function waveformNavigatorPaperYResolve(relativeY: number, heightPx: number) {
  if (!Number.isFinite(relativeY) || !Number.isFinite(heightPx) || heightPx <= 0) return NaN;
  return 1 - (relativeY / heightPx);
}

function rangeGripDragTargetResolve(noteCenterGripSelected: boolean, primaryCenterGripSelected: boolean) {
  if (noteCenterGripSelected) return { rangeKind: "note", dragMode: "move" } as RangeDragTarget;
  if (primaryCenterGripSelected) return { rangeKind: "primary", dragMode: "move" } as RangeDragTarget;
  return null;
}

function waveformMsAtPointerResolve(plot: HTMLElement, event: MouseEvent) {
  const axis = waveformAxisRangeResolve(plot);
  if (!axis) return NaN;
  const rect = plot.getBoundingClientRect();
  const localPx = event.clientX - rect.left - axis.leftPx;
  const ratio = clamp01(localPx / axis.widthPx);
  return axis.min + (axis.max - axis.min) * ratio;
}

function waveformAxisRangeResolve(plot: HTMLElement) {
  const fullLayout = (plot as any)?._fullLayout;
  const size = fullLayout?._size;
  const xAxis = fullLayout?.xaxis;
  const range = Array.isArray(xAxis?.range) ? xAxis.range : null;
  if (!size || !range || range.length < 2) return null;
  const min = Number(range[0]);
  const max = Number(range[1]);
  if (!Number.isFinite(min) || !Number.isFinite(max) || max <= min) return null;
  const widthPx = Number(size.w);
  const leftPx = Number(size.l);
  if (!Number.isFinite(widthPx) || widthPx <= 1 || !Number.isFinite(leftPx)) return null;
  return { min, max, widthPx, leftPx };
}

function clamp01(value: number) {
  return Math.min(1, Math.max(0, value));
}

function rangeMatchesExactly(
  left: { start: number; end: number } | null | undefined,
  right: { start: number; end: number } | null | undefined,
) {
  if (!left || !right) return false;
  return left.start === right.start && left.end === right.end;
}

export function rangeDragTargetResolve(
  cursorMs: number,
  axisMinMs: number,
  axisMaxMs: number,
  axisWidthPx: number,
  primaryRange: WaveRange | null,
  noteRange: WaveRange | null,
  preferNoteRange = false,
): RangeDragTarget | null {
  const toleranceMs = ((axisMaxMs - axisMinMs) / axisWidthPx) * RANGE_DRAG_EDGE_TOLERANCE_PX;
  const noteTarget = rangeDragTargetForRangeResolve(cursorMs, noteRange, toleranceMs);
  const primaryTarget = rangeDragTargetForRangeResolve(cursorMs, primaryRange, toleranceMs);
  if (preferNoteRange && noteTarget) return { rangeKind: "note", dragMode: noteTarget };
  if (primaryTarget) return { rangeKind: "primary", dragMode: primaryTarget };
  if (noteTarget) return { rangeKind: "note", dragMode: noteTarget };
  return null;
}

function rangeDragTargetForRangeResolve(
  cursorMs: number,
  range: WaveRange | null,
  toleranceMs: number,
): RangeDragMode | null {
  if (!range) return null;
  const leftDistance = Math.abs(cursorMs - range.start);
  const rightDistance = Math.abs(cursorMs - range.end);
  if (leftDistance <= toleranceMs && leftDistance <= rightDistance) return "resize-left";
  if (rightDistance <= toleranceMs) return "resize-right";
  if (cursorMs > range.start && cursorMs < range.end) return "move";
  return null;
}

export function rangeDragApply(
  startRange: WaveRange,
  startCursorMs: number,
  currentCursorMs: number,
  dragMode: RangeDragMode,
  axisMinMs: number,
  axisMaxMs: number,
) {
  if (dragMode === "resize-left") {
    const start = clampRange(currentCursorMs, axisMinMs, startRange.end - RANGE_DRAG_MIN_WIDTH_MS);
    return { start, end: startRange.end };
  }
  if (dragMode === "resize-right") {
    const end = clampRange(currentCursorMs, startRange.start + RANGE_DRAG_MIN_WIDTH_MS, axisMaxMs);
    return { start: startRange.start, end };
  }
  const width = startRange.end - startRange.start;
  const delta = currentCursorMs - startCursorMs;
  let start = startRange.start + delta;
  let end = startRange.end + delta;
  if (start < axisMinMs) {
    start = axisMinMs;
    end = start + width;
  }
  if (end > axisMaxMs) {
    end = axisMaxMs;
    start = end - width;
  }
  return { start, end };
}

function clampRange(value: number, min: number, max: number) {
  if (value < min) return min;
  if (value > max) return max;
  return value;
}

function plotlyWaveToolsEnabledResolve() {
  const api = (window as any).ResonateWaveformInteractions;
  if (typeof api?.plotlyWaveToolsEnabledResolve === "function") {
    return api.plotlyWaveToolsEnabledResolve((window as any).__RESONATE_PLOTLY_WAVE_TOOLS__);
  }
  const runtime = (window as any).__RESONATE_PLOTLY_WAVE_TOOLS__;
  return typeof runtime === "boolean" ? runtime : false;
}

export function waveformRangeHandlersBuild(deps: WaveformViewDeps) {
  return {
    onPrimaryRangeChange: (range: any) => {
      deps.state.viewRangeMs = range;
      deps.setStatus(range ? "Analyzing selected region" : "Analyzing full clip");
      if (!primaryRangePipelineShouldTriggerFromRangeChange(deps.state, range)) return;
      deps.runResonatePipeline("range").catch((err: any) => console.error("[Resonance Reader] FFT refresh failed", err));
    },
    onNoteSelectionRangeChange: (range: any) => {
      deps.state.noteSelectionRangeMs = range;
      deps.setStatus(range ? "Analyzing selected tap window" : "Analyzing full clip");
      if (!noteRangePipelineShouldTriggerFromRangeChange(deps.state, range)) return;
      deps.runResonatePipeline("tap-range").catch((err: any) => console.error("[Resonance Reader] FFT refresh failed", err));
    },
  };
}
