import { resolveColorHexFromRole } from "./resonate_color_roles.js";

export type ModeMeta = { label: string; aliasHtml: string; aliasText: string; tooltip: string; color: string };

export type MeasureMode = "guitar" | "played_note" | "peak_analysis" | "plate_stock" | "brace_stock";
export type ModeBand = { low: number; high: number };
export type ModeBandMap = Record<string, ModeBand>;
export type ModeProfile = { bands: ModeBandMap; meta: Record<string, ModeMeta> };

const GUITAR_BANDS: ModeBandMap = {
  air: { low: 75, high: 115 },
  top: { low: 150, high: 205 },
  back: { low: 210, high: 260 },
};

const GUITAR_META: Record<string, ModeMeta> = {
  air: {
    label: "Air",
    aliasHtml: "T(1,1)<sub>1</sub>",
    aliasText: "T(1,1)₁",
    tooltip: "Air (T(1,1)₁)\nHelmholtz air resonance of the cavity.",
    color: resolveColorHexFromRole("airMode"),
  },
  top: {
    label: "Top",
    aliasHtml: "T(1,1)<sub>2</sub>",
    aliasText: "T(1,1)₂",
    tooltip: "Top (T(1,1)₂)\nPrimary top-plate low-frequency mode.",
    color: resolveColorHexFromRole("topMode"),
  },
  back: {
    label: "Back",
    aliasHtml: "T(1,1)<sub>3</sub>",
    aliasText: "T(1,1)₃",
    tooltip: "Back (T(1,1)₃)\nPrimary back-plate low-frequency mode.",
    color: resolveColorHexFromRole("backMode"),
  },
};

const PLATE_STOCK_BANDS: ModeBandMap = {
  long: { low: 65, high: 100 },
  cross: { low: 110, high: 140 },
  transverse: { low: 24, high: 55 },
};

const PLATE_STOCK_META: Record<string, ModeMeta> = {
  long: {
    label: "Long",
    aliasHtml: "L",
    aliasText: "L",
    tooltip: "Long\nLong-grain plate mode.",
    color: resolveColorHexFromRole("plateLongMode"),
  },
  cross: {
    label: "Cross",
    aliasHtml: "C",
    aliasText: "C",
    tooltip: "Cross\nCross-grain plate mode.",
    color: resolveColorHexFromRole("plateCrossMode"),
  },
  transverse: {
    label: "Transverse",
    aliasHtml: "T",
    aliasText: "T",
    tooltip: "Transverse\nTransverse/twisting plate mode.",
    color: resolveColorHexFromRole("plateTransverseMode"),
  },
};

const BRACE_STOCK_BANDS: ModeBandMap = {
  long: { low: 100, high: 500 },
};

const BRACE_STOCK_META: Record<string, ModeMeta> = {
  long: {
    label: "Long",
    aliasHtml: "L",
    aliasText: "L",
    tooltip: "Long\nLong-grain brace-stock mode.",
    color: resolveColorHexFromRole("plateLongMode"),
  },
};

const MODE_PROFILES: Record<MeasureMode, ModeProfile> = {
  guitar: { bands: GUITAR_BANDS, meta: GUITAR_META },
  played_note: { bands: GUITAR_BANDS, meta: GUITAR_META },
  peak_analysis: { bands: GUITAR_BANDS, meta: GUITAR_META },
  plate_stock: { bands: PLATE_STOCK_BANDS, meta: PLATE_STOCK_META },
  brace_stock: { bands: BRACE_STOCK_BANDS, meta: BRACE_STOCK_META },
};

export const modeBands = GUITAR_BANDS;
export const MODE_META = GUITAR_META;

export function measureModeNormalize(input: unknown): MeasureMode {
  if (input === "played_note") return "played_note";
  if (input === "peak_analysis") return "peak_analysis";
  if (input === "plate_stock" || input === "top") return "plate_stock";
  if (input === "back") return "brace_stock";
  if (input === "brace_stock") return "brace_stock";
  return "guitar";
}

export function modeProfileResolveFromMeasureMode(measureMode: unknown): ModeProfile {
  return MODE_PROFILES[measureModeNormalize(measureMode)];
}

export function peakAnalysisSourceMeasureModeResolve(state: Record<string, unknown> | null | undefined): MeasureMode {
  const measureMode = measureModeNormalize(state?.measureMode);
  if (measureMode !== "peak_analysis") return measureMode;
  const sourceMode = measureModeNormalize(state?.peakAnalysisSourceMeasureMode);
  return sourceMode === "peak_analysis" ? "guitar" : sourceMode;
}

export function measureModeLabelBuild(measureMode: unknown): string {
  const normalized = measureModeNormalize(measureMode);
  if (normalized === "played_note") return "Played note";
  if (normalized === "peak_analysis") return "Peak/Q";
  if (normalized === "plate_stock") return "Plate stock";
  if (normalized === "brace_stock") return "Brace stock";
  return "Guitar";
}

export function modeProfileResolveFromState(state: Record<string, unknown> | null | undefined): ModeProfile {
  return modeProfileResolveFromMeasureMode(peakAnalysisSourceMeasureModeResolve(state));
}
