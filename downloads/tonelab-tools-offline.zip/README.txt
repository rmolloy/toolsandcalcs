ToneLab Tools Offline Folder

Open "Open ToneLab Tools.html" to launch the tool index.

The tools run locally from this folder without an internet connection or remote server.

If your browser blocks Resonance Reader microphone access from a direct file,
on macOS double-click "Start ToneLab Tools Server.command" and use the local address it opens.
