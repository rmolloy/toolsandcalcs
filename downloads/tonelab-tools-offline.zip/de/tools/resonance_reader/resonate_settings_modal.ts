import { SETTINGS_IDS } from "./resonate_settings_ids.js";
import { qSettingsControlsBind, qSettingsControlsReset, qSettingsControlsSync } from "./resonate_q_settings_controls.js";
import {
  settingsAudioInputBind,
  settingsAudioInputsRefresh,
} from "./resonate_audio_input_select.js";
import {
  settingsBooleanPatchBuild,
  settingsDebugPatchBuild,
  settingsProfileValueRead,
  settingsSmoothingValueRead,
} from "./resonate_settings_model.js";
import {
  settingsPipelineRefresh,
  type SettingsRefreshDeps,
} from "./resonate_settings_refresh.js";

export {
  settingsBooleanPatchBuild,
  settingsDebugPatchBuild,
  settingsFiniteNumberPatchBuild,
  settingsNumberPatchBuild,
  settingsPositiveNumberPatchBuild,
  settingsProfilePatchBuild,
  settingsProfileValueRead,
  settingsSmoothingPatchBuild,
} from "./resonate_settings_model.js";

export function settingsModalBind(deps: SettingsRefreshDeps) {
  const dialog = settingsDialogElementGet();
  const trigger = buttonElementGet(SETTINGS_IDS.trigger);
  if (!dialog || !trigger) return;

  trigger.addEventListener("click", () => {
    settingsControlsSyncFromRuntime();
    qSettingsControlsSync(deps.state);
    void settingsAudioInputsRefresh();
    settingsDialogOpen(dialog);
  });

  buttonElementGet(SETTINGS_IDS.audioRefresh)?.addEventListener("click", () => {
    void settingsAudioInputsRefresh();
  });

  settingsAudioInputBind();
  qSettingsControlsBind(deps);

  buttonElementGet(SETTINGS_IDS.reset)?.addEventListener("click", () => {
    settingsDebugApiGet()?.reset?.();
    qSettingsControlsReset(deps.state);
    settingsControlsSyncFromRuntime();
    settingsPipelineRefresh(deps);
  });

  buttonElementGet(SETTINGS_IDS.done)?.addEventListener("click", () => {
    settingsPipelineRefresh(deps);
  });

  settingsFftSelectsGet().forEach((select) => {
    select.addEventListener("change", () => {
      settingsDebugApiGet()?.set?.(settingsDebugPatchBuild(select.id, select.value));
      settingsControlsSyncFromRuntime();
      settingsPipelineRefresh(deps);
    });
  });

  settingsFftNumberInputsGet().forEach((input) => {
    input.addEventListener("change", () => {
      settingsDebugApiGet()?.set?.(settingsDebugPatchBuild(input.id, input.value));
      settingsControlsSyncFromRuntime();
      settingsPipelineRefresh(deps);
    });
  });

  settingsFftToggleInputsGet().forEach((input) => {
    input.addEventListener("change", () => {
      settingsDebugApiGet()?.set?.(settingsBooleanPatchBuild(input.id, input.checked));
      settingsControlsSyncFromRuntime();
      settingsPipelineRefresh(deps);
    });
  });

}

function settingsDialogOpen(dialog: HTMLDialogElement) {
  if (dialog.open) return;
  dialog.showModal();
}

function settingsControlsSyncFromRuntime() {
  const flags = settingsDebugApiGet()?.show?.() || {};
  selectValueWrite(SETTINGS_IDS.profile, settingsProfileValueRead(flags));
  selectValueWrite(SETTINGS_IDS.scope, flags.fftInputScope || "");
  selectValueWrite(SETTINGS_IDS.window, flags.fftWindow || "");
  selectValueWrite(SETTINGS_IDS.resolution, flags.fftResolution || "");
  selectValueWrite(SETTINGS_IDS.smoothing, settingsSmoothingValueRead(flags));
  selectValueWrite(SETTINGS_IDS.averaging, flags.spectrumAveragingMode || "off");
  selectValueWrite(SETTINGS_IDS.displayRange, flags.spectrumDisplayRange || "");
  selectValueWrite(SETTINGS_IDS.dbScale, flags.spectrumDbScale || "");
  selectValueWrite(SETTINGS_IDS.yAxis, flags.spectrumYAxisMode || "");
  selectValueWrite(SETTINGS_IDS.xScale, flags.spectrumXAxisScale || "");
  numberValueWrite(SETTINGS_IDS.xMin, flags.spectrumXAxisMin);
  numberValueWrite(SETTINGS_IDS.xMax, flags.spectrumXAxisMax);
  numberValueWrite(SETTINGS_IDS.yMin, flags.spectrumYAxisMin);
  numberValueWrite(SETTINGS_IDS.yMax, flags.spectrumYAxisMax);
  numberValueWrite(SETTINGS_IDS.smoothingBins, flags.spectrumSmoothingBins);
  numberValueWrite(SETTINGS_IDS.smoothingHz, flags.spectrumSmoothingHz);
  numberValueWrite(SETTINGS_IDS.lineWidth, flags.spectrumLineWidth);
  numberValueWrite(SETTINGS_IDS.tapSliceWindowMs, flags.tapSliceWindowMs);
  numberValueWrite(SETTINGS_IDS.energyBandWidthHz, flags.energyBandWidthHz);
  toggleCheckedWrite(SETTINGS_IDS.tapAveraging, Boolean(flags.useTapAveraging));
  toggleCheckedWrite(SETTINGS_IDS.peakHold, Boolean(flags.usePeakHold));
  toggleCheckedWrite(SETTINGS_IDS.peakRefine, flags.useParabolicPeakRefine !== false);
  toggleCheckedWrite(SETTINGS_IDS.polymaxValidation, Boolean(flags.usePolymaxValidation));
}

function settingsFftSelectsGet() {
  return [
    SETTINGS_IDS.profile,
    SETTINGS_IDS.scope,
    SETTINGS_IDS.window,
    SETTINGS_IDS.resolution,
    SETTINGS_IDS.smoothing,
    SETTINGS_IDS.averaging,
    SETTINGS_IDS.displayRange,
    SETTINGS_IDS.dbScale,
    SETTINGS_IDS.yAxis,
    SETTINGS_IDS.xScale,
  ].map(selectElementGet).filter(Boolean) as HTMLSelectElement[];
}

function settingsFftNumberInputsGet() {
  return [
    SETTINGS_IDS.xMin,
    SETTINGS_IDS.xMax,
    SETTINGS_IDS.yMin,
    SETTINGS_IDS.yMax,
    SETTINGS_IDS.smoothingBins,
    SETTINGS_IDS.smoothingHz,
    SETTINGS_IDS.lineWidth,
    SETTINGS_IDS.tapSliceWindowMs,
    SETTINGS_IDS.energyBandWidthHz,
  ].map(inputElementGet).filter(Boolean) as HTMLInputElement[];
}

function settingsFftToggleInputsGet() {
  return [
    SETTINGS_IDS.tapAveraging,
    SETTINGS_IDS.peakHold,
    SETTINGS_IDS.peakRefine,
    SETTINGS_IDS.polymaxValidation,
  ].map(inputElementGet).filter(Boolean) as HTMLInputElement[];
}

function selectValueWrite(id: string, value: string) {
  const select = selectElementGet(id);
  if (!select) return;
  select.value = value;
}

function numberValueWrite(id: string, value: number | null | undefined) {
  const input = inputElementGet(id);
  if (!input) return;
  input.value = Number.isFinite(value) ? String(value) : "";
}

function toggleCheckedWrite(id: string, checked: boolean) {
  const input = inputElementGet(id);
  if (!input) return;
  input.checked = checked;
}

function settingsDebugApiGet() {
  return (window as any).ResonanceDebug;
}

function settingsDialogElementGet() {
  return document.getElementById(SETTINGS_IDS.dialog) as HTMLDialogElement | null;
}

function buttonElementGet(id: string) {
  return document.getElementById(id) as HTMLButtonElement | null;
}

function selectElementGet(id: string) {
  return document.getElementById(id) as HTMLSelectElement | null;
}

function inputElementGet(id: string) {
  return document.getElementById(id) as HTMLInputElement | null;
}
