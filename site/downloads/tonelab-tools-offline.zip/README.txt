ToneLab Tools Offline Folder

Open "Open ToneLab Tools.html" to launch the tool index.

The tools run locally from this folder without an internet connection or remote server.

If your browser blocks Resonance Reader microphone access from a direct file,
on macOS double-click "Start ToneLab Tools Server.command" and use the local address it opens.

Lutherie Academy website deployment

1. Upload the original zip to /rtools/downloads/ and keep its filename unchanged.
2. Extract the zip contents directly into /rtools without adding an enclosing folder.
3. Existing wrapper pages can keep using /rtools/tools/<tool-name>/index.html iframe paths.
4. The setup calculator path is /rtools/tools/guitar_setup_calculator/index.html.
