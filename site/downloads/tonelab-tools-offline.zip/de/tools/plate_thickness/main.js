"use strict";
/*
© 2025 Rick Molloy. All rights reserved.

Panel thickness calculator UI logic.
*/
// localized-runtime-messages:start
const plateThicknessRuntimeMessages = Object.freeze({
    bodyLength: "Korpuslänge",
    crossFreq: "Querfrequenz",
    downloadJson: "JSON herunterladen",
    longFreq: "Längsfrequenz",
    lowerBout: "Unterbugbreite",
    panelHeight: "Plattenstärke",
    panelLength: "Plattenlänge",
    panelMass: "Plattenmasse",
    panelWidth: "Plattenbreite",
    jsonPackageDownloaded: "JSON-Paket heruntergeladen",
    liveComputedFromInputs: "Live: aus den aktuellen Eingaben berechnet",
    loadedJsonPackage: "JSON-Paket geladen",
    locale: "de",
    notebook: "Notizbuch",
    notebookEventRestored: "Notizbuchereignis wiederhergestellt.",
    notebookSavingUnavailable: "Das Speichern im Notizbuch ist hier nicht verfügbar. Laden Sie stattdessen den Export herunter.",
    plateStock: "Plattenholz",
    plateThickness: "Plattenstärke",
    positiveNumberRequired: "{field} muss eine endliche, positive Zahl sein.",
    save: "Speichern",
    savedToNotebook: "In {notebookName} gespeichert.",
    savePlateThickness: "Plattenstärke speichern",
    targetFreq: "Zielfrequenz",
    twistFreq: "Torsionsfrequenz",
    unableToComputeThickness: "Die Dicke kann mit den angegebenen Werten nicht berechnet werden.",
    unableToLoadJsonPackage: "JSON-Paket kann nicht geladen werden",
});
// localized-runtime-messages:end
(function initPlateThicknessTool() {
    const calculator = (typeof window !== "undefined" && window.PlateThickness) ? window.PlateThickness : null;
    const queryParams = (typeof window !== "undefined" && window.PlateThicknessQueryParams)
        ? window.PlateThicknessQueryParams
        : null;
    if (!calculator) {
        throw new Error("PlateThickness calculator unavailable. Ensure calculator.js is loaded before main.js.");
    }
    if (!queryParams) {
        throw new Error("PlateThickness query params unavailable. Ensure query_params.js is loaded before main.js.");
    }
    const calc = calculator;
    const defaults = {
        bodyLength: 0.494,
        lowerBout: 0.381,
        panelMass: 0.2114,
        panelHeight: 0.0041,
        panelLength: 0.555,
        panelWidth: 0.227,
        longFreq: 74, // Hz
        crossFreq: 109, // Hz
        twistFreq: 42, // Hz
        targetFreq: 75 // Hz
    };
    const bodyPresetGeometry = {
        gore_medium_ss: { bodyLength: 490, lowerBout: 390 },
        obrien_om_ss: { bodyLength: 494, lowerBout: 381 },
        martin_om_ss: { bodyLength: 492, lowerBout: 381 },
        obrien_classical: { bodyLength: 494, lowerBout: 365 },
    };
    const fields = {};
    document.querySelectorAll("[data-field]").forEach((input) => {
        const key = input.dataset.field;
        if (key)
            fields[key] = input;
    });
    const lengthFieldKeys = new Set(["lower_bout", "body_length", "panel_length", "panel_width", "panel_height"]);
    const lengthFields = createPlateLengthFields();
    let solvedThicknessMm = null;
    const bodyPresetSelect = document.getElementById("body_preset");
    const resultEls = {
        thickness: document.getElementById("result_thickness"),
        mass: document.getElementById("result_mass"),
        density: document.getElementById("result_density"),
        EL: document.getElementById("result_el"),
        EC: document.getElementById("result_ec"),
        ratio: document.getElementById("result_ratio"),
        shear: document.getElementById("result_shear"),
        status: document.getElementById("result_status")
    };
    const saveButton = document.getElementById("save_results");
    const loadButton = document.getElementById("load_results");
    const loadFileInput = document.getElementById("load_results_file");
    const saveRunner = readPlateThicknessSaveRunner();
    const perTabSession = readPlateThicknessPerTabSession();
    function format(value, { digits = 2, notation = "standard" } = {}) {
        if (!Number.isFinite(value))
            return "—";
        return new Intl.NumberFormat(plateThicknessRuntimeMessages.locale, {
            minimumFractionDigits: digits,
            maximumFractionDigits: digits,
            notation
        }).format(value);
    }
    function readInputs() {
        const values = {};
        for (const [key, input] of Object.entries(fields)) {
            const value = lengthFields && lengthFieldKeys.has(key) ? lengthFields.read(key) : parseFloat(input.value);
            values[key] = value;
        }
        return values;
    }
    function readCurrentPlateThicknessSaveSnapshot() {
        return {
            inputs: readCurrentPlateThicknessSaveInputs(),
            results: readCurrentPlateThicknessSaveResults(),
        };
    }
    function setResults(result) {
        solvedThicknessMm = result.thicknessMm;
        renderThicknessLength();
        if (resultEls.mass)
            resultEls.mass.textContent = `${format(result.projectedMassG, { digits: 1 })} g`;
        if (resultEls.density)
            resultEls.density.textContent = `${format(result.density, { digits: 1 })} kg/m³`;
        if (resultEls.EL)
            resultEls.EL.textContent = `${format(result.EL / 1e9, { digits: 2 })} GPa`;
        if (resultEls.EC)
            resultEls.EC.textContent = `${format(result.EC / 1e9, { digits: 2 })} GPa`;
        if (resultEls.ratio)
            resultEls.ratio.textContent = format(result.ELoverEC, { digits: 2 });
        if (resultEls.shear)
            resultEls.shear.textContent = `${format(result.GLC / 1e9, { digits: 2 })} GPa`;
        if (resultEls.status)
            resultEls.status.textContent = plateThicknessRuntimeMessages.liveComputedFromInputs;
    }
    function setError(message) {
        solvedThicknessMm = null;
        if (resultEls.thickness)
            resultEls.thickness.textContent = "—";
        if (resultEls.mass)
            resultEls.mass.textContent = "—";
        if (resultEls.density)
            resultEls.density.textContent = "—";
        if (resultEls.EL)
            resultEls.EL.textContent = "—";
        if (resultEls.EC)
            resultEls.EC.textContent = "—";
        if (resultEls.ratio)
            resultEls.ratio.textContent = "—";
        if (resultEls.shear)
            resultEls.shear.textContent = "—";
        if (resultEls.status)
            resultEls.status.textContent = message;
    }
    async function loadResults() {
        var _a;
        const file = (_a = loadFileInput === null || loadFileInput === void 0 ? void 0 : loadFileInput.files) === null || _a === void 0 ? void 0 : _a[0];
        if (!file) {
            return;
        }
        try {
            const snapshot = await window.PlateThicknessSaveSurface.readPlateThicknessSavePackageFile(file);
            applyLoadedPlateThicknessSnapshot(snapshot);
            if (resultEls.status)
                resultEls.status.textContent = plateThicknessRuntimeMessages.loadedJsonPackage;
        }
        catch (_error) {
            if (resultEls.status)
                resultEls.status.textContent = plateThicknessRuntimeMessages.unableToLoadJsonPackage;
        }
        finally {
            if (loadFileInput)
                loadFileInput.value = "";
        }
    }
    function run() {
        var _a, _b, _c, _d, _e, _f;
        persistPlateThicknessPerTabSession();
        try {
            const raw = readInputs();
            const mapped = {
                bodyLength: ((_a = raw.body_length) !== null && _a !== void 0 ? _a : 0) / 1000,
                lowerBout: ((_b = raw.lower_bout) !== null && _b !== void 0 ? _b : 0) / 1000,
                panelMass: ((_c = raw.panel_mass) !== null && _c !== void 0 ? _c : 0) / 1000,
                panelHeight: ((_d = raw.panel_height) !== null && _d !== void 0 ? _d : 0) / 1000,
                panelLength: ((_e = raw.panel_length) !== null && _e !== void 0 ? _e : 0) / 1000,
                panelWidth: ((_f = raw.panel_width) !== null && _f !== void 0 ? _f : 0) / 1000,
                longFreq: raw.long_freq,
                crossFreq: raw.cross_freq,
                twistFreq: raw.twist_freq,
                targetFreq: raw.target_freq
            };
            const result = calc.computePlateSolution(mapped);
            setResults(result);
        }
        catch (error) {
            setError(readCalculationErrorMessage(error));
        }
    }
    function reset(clearPerTabSession = false) {
        if (clearPerTabSession) {
            perTabSession === null || perTabSession === void 0 ? void 0 : perTabSession.clear();
        }
        const bodyPresetKey = readDefaultBodyPresetKey();
        if (bodyPresetSelect) {
            bodyPresetSelect.value = bodyPresetKey;
        }
        Object.entries(fields).forEach(([key]) => {
            const defaultKey = key;
            const value = defaults[camelCase(defaultKey)];
            if (typeof value === "number") {
                const scaled = scaleForField(key, value);
                writeCanonicalField(key, Number.isFinite(scaled) ? formatNumber(scaled) : "");
            }
        });
        applyBodyPresetGeometry(bodyPresetKey);
        restorePlateThicknessPerTabSession();
        applyQueryParams();
        run();
    }
    function applySelectedBodyPreset() {
        if (!bodyPresetSelect)
            return;
        applyBodyPresetGeometry(bodyPresetSelect.value);
        run();
    }
    function readDefaultBodyPresetKey() {
        const configuredKey = document.body.dataset.plateDefaultPreset;
        return configuredKey && configuredKey in bodyPresetGeometry
            ? configuredKey
            : "obrien_om_ss";
    }
    function applyBodyPresetGeometry(bodyPresetKey) {
        const preset = bodyPresetGeometry[bodyPresetKey];
        if (!preset)
            return;
        writeCanonicalField("body_length", formatNumber(preset.bodyLength));
        writeCanonicalField("lower_bout", formatNumber(preset.lowerBout));
    }
    async function saveResults() {
        await saveRunner.runPlateThicknessSaveAction({
            readSnapshot: readCurrentPlateThicknessSaveSnapshot,
            setStatus: writeStatusText,
        });
    }
    function scaleForField(key, baseValue) {
        if (key.includes("mass"))
            return baseValue * 1000;
        if (key.includes("height") || key.includes("length") || key.includes("width") || key.includes("body") || key.includes("bout")) {
            return baseValue * 1000;
        }
        return baseValue;
    }
    function camelCase(snake) {
        return snake.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
    }
    function applyQueryParams() {
        if (typeof window === "undefined" || !window.location)
            return;
        const canonicalFields = Object.fromEntries(Object.entries(readCurrentPlateThicknessSaveInputs()).map(([key, value]) => [key, { value }]));
        const changed = queryParams.applyToFields(canonicalFields, window.location.search, String);
        if (!changed)
            return;
        Object.entries(canonicalFields).forEach(([key, input]) => writeCanonicalField(key, input.value));
        run();
    }
    function applyLoadedPlateThicknessSnapshot(snapshot) {
        const plan = window.PlateThicknessSaveSnapshot.buildPlateThicknessSnapshotApplyPlan(snapshot, defaults);
        Object.entries(plan.fields).forEach(([key, value]) => {
            if (fields[key]) {
                writeCanonicalField(key, String(value || ""));
            }
        });
        run();
    }
    function readPlateThicknessPerTabSession() {
        var _a;
        return ((_a = window.PerTabToolSession) === null || _a === void 0 ? void 0 : _a.perTabToolSessionCreate)
            ? window.PerTabToolSession.perTabToolSessionCreate({ toolId: "plate_thickness", version: 1 })
            : null;
    }
    function persistPlateThicknessPerTabSession() {
        perTabSession === null || perTabSession === void 0 ? void 0 : perTabSession.write({
            bodyPreset: bodyPresetSelect === null || bodyPresetSelect === void 0 ? void 0 : bodyPresetSelect.value,
            fields: readCurrentPlateThicknessSaveInputs(),
        });
    }
    function restorePlateThicknessPerTabSession() {
        const snapshot = perTabSession === null || perTabSession === void 0 ? void 0 : perTabSession.read();
        if (!snapshot) {
            return;
        }
        if (bodyPresetSelect && typeof snapshot.bodyPreset === "string") {
            bodyPresetSelect.value = snapshot.bodyPreset;
        }
        Object.entries(snapshot.fields || {}).forEach(([key, value]) => {
            if (fields[key]) {
                writeCanonicalField(key, String(value !== null && value !== void 0 ? value : ""));
            }
        });
    }
    async function applyPlateThicknessSaveSurface() {
        const saveSurface = await saveRunner.readPlateThicknessSaveSurface();
        if (saveButton) {
            saveButton.textContent = saveSurface.label || plateThicknessRuntimeMessages.downloadJson;
            saveButton.title = saveSurface.hint || "";
        }
    }
    function readPlateThicknessNotebookRestoreApi() {
        var _a;
        return ((_a = window.PlateThicknessNotebookRestore) === null || _a === void 0 ? void 0 : _a.restorePlateThicknessNotebookEventIntoUi)
            ? window.PlateThicknessNotebookRestore
            : null;
    }
    function readCurrentPlateThicknessSaveInputs() {
        return Object.fromEntries(Object.entries(fields).map(([key, input]) => [key, lengthFields && lengthFieldKeys.has(key) ? lengthFields.readText(key) : input.value]));
    }
    function readCurrentPlateThicknessSaveResults() {
        var _a, _b, _c, _d, _e, _f, _g;
        return {
            result_thickness: solvedThicknessMm === null ? ((_a = resultEls.thickness) === null || _a === void 0 ? void 0 : _a.textContent) || "" : `${format(solvedThicknessMm, { digits: 2 })} mm`,
            result_mass: ((_b = resultEls.mass) === null || _b === void 0 ? void 0 : _b.textContent) || "",
            result_density: ((_c = resultEls.density) === null || _c === void 0 ? void 0 : _c.textContent) || "",
            result_el: ((_d = resultEls.EL) === null || _d === void 0 ? void 0 : _d.textContent) || "",
            result_ec: ((_e = resultEls.EC) === null || _e === void 0 ? void 0 : _e.textContent) || "",
            result_ratio: ((_f = resultEls.ratio) === null || _f === void 0 ? void 0 : _f.textContent) || "",
            result_shear: ((_g = resultEls.shear) === null || _g === void 0 ? void 0 : _g.textContent) || "",
        };
    }
    function readPlateThicknessSaveRunner() {
        var _a;
        if ((_a = window.PlateThicknessSaveTarget) === null || _a === void 0 ? void 0 : _a.plateThicknessSaveRunnerCreate) {
            return window.PlateThicknessSaveTarget.plateThicknessSaveRunnerCreate({
                messages: plateThicknessRuntimeMessages,
            });
        }
        return {
            readPlateThicknessSaveSurface() {
                return Promise.resolve({
                    mode: "offline",
                    label: plateThicknessRuntimeMessages.downloadJson,
                    hint: "",
                });
            },
            runPlateThicknessSaveAction(request) {
                const savePackage = window.PlateThicknessSaveSurface.buildPlateThicknessSavePackage(request.readSnapshot());
                window.PlateThicknessSaveSurface.downloadPlateThicknessSavePackage(window, savePackage);
                request.setStatus(plateThicknessRuntimeMessages.jsonPackageDownloaded);
                return Promise.resolve(true);
            },
        };
    }
    function writeStatusText(message) {
        if (resultEls.status) {
            resultEls.status.textContent = message;
        }
    }
    function readCalculationErrorMessage(error) {
        const calculationError = error;
        if (calculationError.code === "positive-number-required" && calculationError.field) {
            const fieldName = plateThicknessRuntimeMessages[calculationError.field]
                || calculationError.field;
            return plateThicknessRuntimeMessages.positiveNumberRequired.replace("{field}", fieldName);
        }
        if (calculationError.code === "thickness-computation-failed") {
            return plateThicknessRuntimeMessages.unableToComputeThickness;
        }
        return calculationError.message;
    }
    async function initializePlateThicknessToolSurface() {
        if (await restoreNotebookEventIntoUi()) {
            registerPlateLengthUnits();
            return;
        }
        await applyPlateThicknessSaveSurface();
        registerPlateLengthUnits();
    }
    async function restoreNotebookEventIntoUi() {
        const restoreApi = readPlateThicknessNotebookRestoreApi();
        if (!restoreApi) {
            return false;
        }
        const restored = await restoreApi.restorePlateThicknessNotebookEventIntoUi({
            runtime: window,
            applySnapshot(snapshot) {
                applyLoadedPlateThicknessSnapshot(snapshot);
            },
        });
        if (restored && resultEls.status) {
            resultEls.status.textContent = plateThicknessRuntimeMessages.notebookEventRestored;
        }
        return restored;
    }
    document.querySelectorAll("input[data-field]").forEach((input) => {
        input.addEventListener("input", () => {
            run();
        });
        input.addEventListener("change", () => {
            if (lengthFields && lengthFieldKeys.has(input.dataset.field || "")) {
                presentEditedLength(input.dataset.field);
                run();
                return;
            }
            const value = parseFloat(input.value);
            if (Number.isFinite(value)) {
                input.value = formatNumber(value);
            }
            run();
        });
    });
    const resetBtn = document.getElementById("reset_inputs");
    if (resetBtn)
        resetBtn.addEventListener("click", event => {
            event.preventDefault();
            reset(true);
        });
    if (saveButton)
        saveButton.addEventListener("click", () => void saveResults());
    if (loadButton && loadFileInput)
        loadButton.addEventListener("click", () => loadFileInput.click());
    if (loadFileInput)
        loadFileInput.addEventListener("change", loadResults);
    if (bodyPresetSelect)
        bodyPresetSelect.addEventListener("change", applySelectedBodyPreset);
    reset();
    void initializePlateThicknessToolSurface();
    function createPlateLengthFields() {
        var _a;
        const factory = (_a = window.ToolCanonicalLengthFields) === null || _a === void 0 ? void 0 : _a.createCanonicalLengthFields;
        if (!factory)
            return null;
        return factory({ fields: Object.fromEntries([...lengthFieldKeys].map((key) => {
                var _a, _b, _c;
                return [key, {
                        input: fields[key],
                        label: (_c = (_b = (_a = fields[key]).closest) === null || _b === void 0 ? void 0 : _b.call(_a, "label")) === null || _c === void 0 ? void 0 : _c.querySelector(".field-label"),
                    }];
            })) });
    }
    function writeCanonicalField(key, text) {
        if (lengthFields && lengthFieldKeys.has(key) && text.trim() !== "" && Number.isFinite(Number(text))) {
            lengthFields.write(key, Number(text));
            return;
        }
        fields[key].value = text;
    }
    function presentEditedLength(key) {
        const canonicalMm = lengthFields.read(key);
        if (Number.isFinite(canonicalMm))
            lengthFields.write(key, canonicalMm);
    }
    function registerPlateLengthUnits() {
        var _a;
        if (!lengthFields)
            return;
        (_a = window.ToolLengthUnits) === null || _a === void 0 ? void 0 : _a.register({
            readUnit: () => lengthFields.unit,
            applyUnit: (unit) => {
                lengthFields.applyUnit(unit);
                renderThicknessLength();
            },
        });
    }
    function renderThicknessLength() {
        if (!resultEls.thickness || solvedThicknessMm === null)
            return;
        const unit = (lengthFields === null || lengthFields === void 0 ? void 0 : lengthFields.unit) || "mm";
        const value = unit === "in" ? solvedThicknessMm / 25.4 : solvedThicknessMm;
        resultEls.thickness.textContent = `${format(value, { digits: unit === "in" ? 4 : 2 })} ${unit}`;
    }
    function formatNumber(value) {
        if (!Number.isFinite(value))
            return "";
        const fixed = value.toFixed(2);
        return fixed.replace(/\.?0+$/, "");
    }
})();
