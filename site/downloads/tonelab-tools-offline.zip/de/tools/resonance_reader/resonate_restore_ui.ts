import { measureModeNormalize } from "./resonate_mode_config.js";
import { resonanceLocalizedMessages } from "./resonate_localized_messages.js";
import {
  consumeResonanceNotebookConnectDraft,
  restoreResonanceNotebookConnectDraftState,
} from "./resonate_notebook_connect_draft.js";
import { restoreResonanceNotebookEventIntoState } from "./resonate_notebook_restore.js";
import { perTabSessionResolve } from "./resonate_per_tab_persistence.js";
import { recordingMenuLabelSet } from "./resonate_recording_menu.js";
import { saveStateMarkDirtyAndRender } from "./resonate_save_button.js";
import { takeOverlayControlsRender } from "./resonate_take_overlay_controls.js";
import type { UiBindingsDeps } from "./resonate_ui_bindings_contract.js";

export async function restorePerTabSessionIntoUi(deps: UiBindingsDeps): Promise<boolean> {
  if (!await perTabSessionResolve(deps)?.restoreIntoState(deps.state)) {
    return false;
  }
  restoreNotebookConnectDraftControls(deps.state);
  renderNotebookConnectDraftIntoUi(deps);
  takeOverlayControlsRender(deps);
  saveStateMarkDirtyAndRender(deps.state);
  await refreshRestoredPerTabSession(deps);
  return true;
}

export function restoreNotebookConnectDraftIntoUi(deps: UiBindingsDeps): boolean {
  const draft = consumeResonanceNotebookConnectDraft(window);

  if (!restoreResonanceNotebookConnectDraftState(deps.state, draft)) {
    return false;
  }

  restoreNotebookConnectDraftControls(deps.state);
  renderNotebookConnectDraftIntoUi(deps);
  return true;
}

export async function restoreNotebookEventIntoUi(deps: UiBindingsDeps): Promise<boolean> {
  const restored = await restoreResonanceNotebookEventIntoState({
    runtime: window,
    state: deps.state,
  });

  if (!restored) {
    return false;
  }

  restoreNotebookConnectDraftControls(deps.state);
  renderNotebookConnectDraftIntoUi(deps);
  return true;
}

async function refreshRestoredPerTabSession(deps: UiBindingsDeps) {
  if (!deps.state.currentWave?.wave?.length) return;
  await deps.runResonatePipeline("per-tab-restore");
}

function restoreNotebookConnectDraftControls(state: Record<string, any>) {
  writeMeasureModeSelectValue(state.measureMode);
  recordingMenuLabelSet(
    String(state.recordingLabel || resonanceLocalizedMessages.restoreNotebookDraftLabel),
    state,
  );
}

function writeMeasureModeSelectValue(measureMode: unknown) {
  const select = measureModeSelectElementGet();
  const normalized = measureModeNormalize(measureMode);

  if (!select || !normalized) {
    return;
  }

  select.value = normalized;
}

function renderNotebookConnectDraftIntoUi(deps: UiBindingsDeps) {
  renderNotebookConnectDraftSpectrum(deps);
  renderNotebookConnectDraftModes(deps);
  renderNotebookConnectDraftWaveform(deps);
}

function renderNotebookConnectDraftSpectrum(deps: UiBindingsDeps) {
  const spectrum = deps.state.lastSpectrum;

  if (!spectrum?.freqs?.length || !spectrum?.dbs?.length) {
    return;
  }

  deps.renderSpectrum({
    freqs: spectrum.freqs,
    mags: spectrum.dbs,
    overlay: Array.isArray(deps.state.lastOverlay) ? deps.state.lastOverlay : undefined,
    modes: Array.isArray(deps.state.lastModesDetected) ? deps.state.lastModesDetected : [],
  });
}

function renderNotebookConnectDraftModes(deps: UiBindingsDeps) {
  deps.renderModes(Array.isArray(deps.state.lastModeCards) ? deps.state.lastModeCards : []);
}

function renderNotebookConnectDraftWaveform(deps: UiBindingsDeps) {
  if (!deps.state.currentWave) {
    return;
  }

  deps.renderWaveform(deps.state.currentWave);
}

function measureModeSelectElementGet() {
  return document.getElementById("measure_mode") as HTMLSelectElement | null;
}
