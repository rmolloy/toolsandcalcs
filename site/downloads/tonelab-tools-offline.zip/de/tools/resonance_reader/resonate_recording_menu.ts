import { resonanceLocalizedMessages } from "./resonate_localized_messages.js";

export function recordingMenuLabelSet(label: string, state?: Record<string, any>) {
  if (state) state.recordingLabel = label;
  const menu = takeOverlayMenuElementGet();
  if (!menu) return;
  menu.textContent = label;
  recordingMenuWidthSyncFromLabel(menu, label);
}

export function recordingMenuInitialWidthSync() {
  const menu = takeOverlayMenuElementGet();
  if (!menu) return;
  recordingMenuWidthSyncFromLabel(
    menu,
    menu.textContent || resonanceLocalizedMessages.transportDemoPrompt,
  );
}

export function takeOverlayMenuElementGet() {
  return document.getElementById("take_overlay_menu") as HTMLButtonElement | null;
}

function recordingMenuWidthSyncFromLabel(menu: HTMLButtonElement, label: string) {
  const charUnits = recordingMenuWidthCharUnitsFromLabel(label);
  menu.style.width = `${charUnits}ch`;
}

function recordingMenuWidthCharUnitsFromLabel(label: string) {
  const minCh = 14;
  const maxCh = 34;
  const paddingCh = 4;
  const textCh = Math.max(0, String(label || "").length);
  return Math.max(minCh, Math.min(maxCh, textCh + paddingCh));
}
