"use strict";

// The Save to Notebook dialog, shared by every tool that saves a capture.
//
// It is the notebook entry the builder is about to write, editable in place:
// the subject as a heading (click to change or create), the title, one line
// for what was heard with descriptor pills, the numbers as they will appear
// in the notebook, the files as a footnote, and Cancel beside Save.
(() => {
  // localized-runtime-messages:start
  const notebookSaveMessages = Object.freeze({
    locale: "en-US",
    asKind: "as {kind}",
    benchSubject: "Bench {kind}",
    cancel: "Cancel",
    changeSubject: "Change subject",
    chooseSubject: "Choose a subject",
    createSubject: "Create “{name}”",
    descriptorBloom: "bloom",
    descriptorBright: "bright",
    descriptorDead: "dead",
    descriptorDiesEarly: "dies early",
    descriptorDull: "dull",
    descriptorEven: "even",
    descriptorHollow: "hollow",
    descriptorLongRing: "long ring",
    descriptorRinging: "ringing",
    descriptorShortRing: "short ring",
    descriptorSings: "sings",
    descriptorStiff: "stiff",
    descriptorTight: "tight",
    descriptorWarm: "warm",
    descriptorWobble: "wobble",
    descriptorWoody: "woody",
    dialogLabel: "Save to Notebook",
    entryTitle: "Entry title",
    findOrCreateSubject: "Find or create a subject",
    heard: "Heard",
    heardPlaceholder: "One line, before the numbers",
    instrument: "Instrument",
    nameExample: "Name it, for example {example}",
    newSubjectKind: "New {kind} · rename any time",
    nothingInNotebook: "Nothing in the notebook yet",
    notebook: "Notebook",
    provenanceCalculated: "calculated",
    provenanceDefault: "default",
    provenanceMeasured: "measured",
    provenanceModeled: "modeled",
    save: "Save",
    saveToSubject: "Save to {subject}",
    savedState: "Saved state",
    subjectRequired: "Choose a subject or create one.",
    subject: "Subject",
    subtypeBraceStock: "Brace Stock",
    subtypeGeneral: "General",
    subtypePlateStock: "Plate Stock",
    subtype: "Subtype",
    toNotebook: "To {notebookName}",
    typeAssembly: "Assembly",
    typeAssemblies: "Assemblies",
    typeBlank: "Blank",
    typeBlanks: "Blanks",
    typeBrace: "Brace",
    typeBraces: "Braces",
    typeFixture: "Fixture",
    typeFixtures: "Fixtures",
    typeGeneric: "Generic",
    typeGenerics: "Generic",
    typeGuitar: "Guitar",
    typeGuitars: "Guitars",
    typeInstrument: "Instrument",
    typeInstruments: "Instruments",
    typeJig: "Jig",
    typeJigs: "Jigs",
    typeMaterial: "Material",
    typeMaterials: "Materials",
    typePart: "Part",
    typeParts: "Parts",
    typePlate: "Plate",
    typePlates: "Plates",
    typeSetupComponent: "Setup Component",
    typeSetupComponents: "Setup Components",
    type: "Type",
    whatYouHeard: "What you heard",
  });
  // localized-runtime-messages:end
  void notebookSaveMessages;

  type NotebookSaveSubject = {
    subjectId?: string;
    displayName?: string;
    typeKey?: string;
    subtypeKey?: string;
  };

  type NotebookSaveNewSubjectSettings = {
    typeKey: string;
    subtypeKey: string;
    displayNamePlaceholder: string;
    typeChoice: boolean;
  };

  type NotebookSaveSummaryRow = {
    label: string;
    value: string;
    provenance?: string;
  };

  type NotebookSaveListeningSettings = {
    descriptors: ListeningDescriptor[];
  };

  type ListeningDescriptor = {
    value: string;
    label: string;
  };

  type NotebookSaveModalArgs = {
    dialogLabel?: string;
    title?: string;
    summary?: NotebookSaveSummaryRow[];
    listening?: { descriptorSet?: string; descriptors?: string[] };
    notebookName?: string;
    subjects?: NotebookSaveSubject[];
    defaultSubjectId?: string;
    packageFiles?: string[];
    newSubject?: Partial<NotebookSaveNewSubjectSettings>;
    eventExtras?: Record<string, unknown>;
  };

  type NotebookSaveModalSettings = {
    dialogLabel: string;
    title: string;
    summary: NotebookSaveSummaryRow[];
    listening: NotebookSaveListeningSettings;
    notebookName: string;
    subjects: NotebookSaveSubject[];
    defaultSubjectId: string;
    packageFiles: string[];
    newSubject: NotebookSaveNewSubjectSettings;
    eventExtras: Record<string, unknown>;
  };

  type NotebookSaveSubjectChoice =
    | { subjectId: string }
    | { newSubject: { typeKey: string; subtypeKey: string; displayName: string } };

  type NotebookSaveSelection = {
    subject: NotebookSaveSubjectChoice;
    event: Record<string, unknown>;
  };

  type NotebookSaveModalResult = NotebookSaveSelection | null;

  type SubjectTypeOption = {
    key: string;
    label: string;
    groupLabel: string;
    subtypes: Array<{ key: string; label: string }>;
  };

  type PickerState = {
    choice: NotebookSaveSubjectChoice | null;
    open: boolean;
  };

  const SUBJECT_TYPE_OPTIONS: SubjectTypeOption[] = [
    subjectTypeOption("GUITAR", notebookSaveMessages.typeGuitar, notebookSaveMessages.typeGuitars),
    subjectTypeOption("MATERIAL", notebookSaveMessages.typeMaterial, notebookSaveMessages.typeMaterials, [
      { key: "PLATE_STOCK", label: notebookSaveMessages.subtypePlateStock },
      { key: "BRACE_STOCK", label: notebookSaveMessages.subtypeBraceStock },
    ]),
    subjectTypeOption("BLANK", notebookSaveMessages.typeBlank, notebookSaveMessages.typeBlanks),
    subjectTypeOption("PART", notebookSaveMessages.typePart, notebookSaveMessages.typeParts),
    subjectTypeOption("PLATE", notebookSaveMessages.typePlate, notebookSaveMessages.typePlates),
    subjectTypeOption("BRACE", notebookSaveMessages.typeBrace, notebookSaveMessages.typeBraces),
    subjectTypeOption("ASSEMBLY", notebookSaveMessages.typeAssembly, notebookSaveMessages.typeAssemblies),
    subjectTypeOption("INSTRUMENT", notebookSaveMessages.typeInstrument, notebookSaveMessages.typeInstruments),
    subjectTypeOption("SETUP_COMPONENT", notebookSaveMessages.typeSetupComponent, notebookSaveMessages.typeSetupComponents),
    subjectTypeOption("JIG", notebookSaveMessages.typeJig, notebookSaveMessages.typeJigs),
    subjectTypeOption("FIXTURE", notebookSaveMessages.typeFixture, notebookSaveMessages.typeFixtures),
    subjectTypeOption("GENERIC", notebookSaveMessages.typeGeneric, notebookSaveMessages.typeGenerics),
  ];

  const GENERAL_SUBTYPE_OPTIONS = [{ key: "", label: notebookSaveMessages.subtypeGeneral }];
  const PROVENANCE_LABELS: Record<string, string> = {
    measured: notebookSaveMessages.provenanceMeasured,
    modeled: notebookSaveMessages.provenanceModeled,
    calculated: notebookSaveMessages.provenanceCalculated,
    default: notebookSaveMessages.provenanceDefault,
  };
  const LISTENING_DESCRIPTOR_SETS: Record<string, ListeningDescriptor[]> = {
    instrument: [
      listeningDescriptor("bloom", notebookSaveMessages.descriptorBloom),
      listeningDescriptor("sings", notebookSaveMessages.descriptorSings),
      listeningDescriptor("even", notebookSaveMessages.descriptorEven),
      listeningDescriptor("warm", notebookSaveMessages.descriptorWarm),
      listeningDescriptor("tight", notebookSaveMessages.descriptorTight),
      listeningDescriptor("stiff", notebookSaveMessages.descriptorStiff),
      listeningDescriptor("hollow", notebookSaveMessages.descriptorHollow),
      listeningDescriptor("wobble", notebookSaveMessages.descriptorWobble),
      listeningDescriptor("dies early", notebookSaveMessages.descriptorDiesEarly),
    ],
    stock: [
      listeningDescriptor("bright", notebookSaveMessages.descriptorBright),
      listeningDescriptor("ringing", notebookSaveMessages.descriptorRinging),
      listeningDescriptor("long ring", notebookSaveMessages.descriptorLongRing),
      listeningDescriptor("woody", notebookSaveMessages.descriptorWoody),
      listeningDescriptor("dull", notebookSaveMessages.descriptorDull),
      listeningDescriptor("dead", notebookSaveMessages.descriptorDead),
      listeningDescriptor("short ring", notebookSaveMessages.descriptorShortRing),
    ],
  };
  const LAST_SUBJECT_STORAGE_KEY = "tonelab.notebook.lastSubjectId";

  function subjectTypeOption(
    key: string,
    label: string,
    groupLabel: string,
    subtypes?: Array<{ key: string; label: string }>,
  ): SubjectTypeOption {
    return {
      key,
      label,
      groupLabel,
      subtypes: subtypes || [{ key: "", label: notebookSaveMessages.subtypeGeneral }],
    };
  }

  function listeningDescriptor(value: string, label: string): ListeningDescriptor {
    return { value, label };
  }

  function openNotebookSaveModal(args?: NotebookSaveModalArgs): Promise<NotebookSaveModalResult> {
    const settings = notebookSaveModalSettingsResolve(args);
    return new Promise((resolve) => {
      const modal = notebookSaveModalElementBuild(settings);
      document.body.appendChild(modal);
      const picker: PickerState = { choice: subjectChoiceDefaultResolve(settings), open: false };
      const detach = notebookSaveModalBindingsAttach(modal, settings, picker, (result) => {
        detach();
        modal.remove();
        resolve(result);
      });
      subjectRender(modal, settings, picker);
    });
  }

  function notebookSaveModalSettingsResolve(args?: NotebookSaveModalArgs): NotebookSaveModalSettings {
    const source = args || {};
    const newSubject = source.newSubject || {};
    const dialogLabel = String(source.dialogLabel || notebookSaveMessages.dialogLabel);
    return {
      dialogLabel,
      title: String(source.title || titleDefaultFromDialogLabel(dialogLabel)),
      summary: summaryRowsResolve(source.summary),
      listening: listeningSettingsResolve(source.listening, String(newSubject.typeKey || "GUITAR")),
      notebookName: String(source.notebookName || notebookSaveMessages.notebook),
      subjects: Array.isArray(source.subjects) ? source.subjects.filter((subject) => subject && typeof subject === "object") : [],
      defaultSubjectId: String(source.defaultSubjectId || ""),
      packageFiles: Array.isArray(source.packageFiles) && source.packageFiles.length ? source.packageFiles : ["state.json"],
      newSubject: {
        typeKey: String(newSubject.typeKey || "GUITAR"),
        subtypeKey: String(newSubject.subtypeKey || ""),
        displayNamePlaceholder: String(newSubject.displayNamePlaceholder || notebookSaveMessages.instrument),
        typeChoice: Boolean(newSubject.typeChoice),
      },
      eventExtras: source.eventExtras || {},
    };
  }

  function titleDefaultFromDialogLabel(dialogLabel: string): string {
    if (dialogLabel === notebookSaveMessages.dialogLabel) return notebookSaveMessages.savedState;
    const stripped = dialogLabel.replace(/^save\s+(to\s+)?/i, "").trim();
    return stripped && stripped.toLowerCase() !== "notebook" ? stripped : notebookSaveMessages.savedState;
  }

  function summaryRowsResolve(rows: unknown): NotebookSaveSummaryRow[] {
    if (!Array.isArray(rows)) return [];
    return rows
      .filter((row) => row && String(row.label || "").trim() && String(row.value || "").trim())
      .map((row) => ({
        label: String(row.label).trim(),
        value: String(row.value).trim(),
        provenance: provenanceResolve(row.provenance),
      }));
  }

  function listeningSettingsResolve(value: NotebookSaveModalArgs["listening"], subjectTypeKey: string): NotebookSaveListeningSettings {
    const source = value || {};
    const custom = Array.isArray(source.descriptors)
      ? source.descriptors
        .map((item) => String(item).trim())
        .filter(Boolean)
        .map((item) => listeningDescriptor(item, item))
      : [];
    const descriptorSet = source.descriptorSet || listeningDescriptorSetForSubjectType(subjectTypeKey);
    return { descriptors: custom.length ? custom : notebookListeningDescriptorOptionsRead(descriptorSet) };
  }

  function listeningDescriptorSetForSubjectType(subjectTypeKey: string): string {
    return String(subjectTypeKey || "").trim().toUpperCase() === "MATERIAL" ? "stock" : "instrument";
  }

  function provenanceResolve(value: unknown): string {
    const label = String(value || "").trim().toLowerCase();
    return Object.prototype.hasOwnProperty.call(PROVENANCE_LABELS, label) ? label : "";
  }

  // ---- default subject ----
  //
  // The dialog never opens without a subject. In order: the subject the tool
  // asked for; the one the builder saved to last, if it is the kind this tool
  // saves (a plate tap should not land on last week's guitar); the first
  // listed subject of that kind; and finally the Bench default for the kind,
  // reused when it already exists and created otherwise. "Bench guitar" is a
  // real subject with a provisional name: renaming it in the Notebook later
  // carries every entry along.

  function subjectChoiceDefaultResolve(settings: NotebookSaveModalSettings): NotebookSaveSubjectChoice {
    const explicit = subjectByIdFind(settings.subjects, settings.defaultSubjectId);
    if (explicit) return { subjectId: String(explicit.subjectId) };

    const ofKind = settings.subjects.filter((subject) => subjectMatchesKind(subject, settings.newSubject));
    const remembered = subjectByIdFind(ofKind, lastSubjectIdRead());
    if (remembered) return { subjectId: String(remembered.subjectId) };
    if (ofKind.length) return { subjectId: String(ofKind[0].subjectId) };

    return benchSubjectChoiceBuild(settings);
  }

  function subjectByIdFind(subjects: NotebookSaveSubject[], subjectId: string): NotebookSaveSubject | undefined {
    const wanted = String(subjectId || "").trim();
    return wanted ? subjects.find((subject) => String(subject.subjectId || "") === wanted) : undefined;
  }

  // A subject with no recorded type is treated as belonging to every kind, so
  // older notebooks that never stored one keep a sensible default.
  function subjectMatchesKind(subject: NotebookSaveSubject, kind: { typeKey: string; subtypeKey: string }): boolean {
    if (!String(subject.subjectId || "").trim()) return false;
    const typeKey = String(subject.typeKey || "").trim().toUpperCase();
    if (!typeKey) return true;
    if (typeKey !== kind.typeKey.toUpperCase()) return false;
    const wantedSubtype = String(kind.subtypeKey || "").trim().toUpperCase();
    return !wantedSubtype || String(subject.subtypeKey || "").trim().toUpperCase() === wantedSubtype;
  }

  function benchSubjectChoiceBuild(settings: NotebookSaveModalSettings): NotebookSaveSubjectChoice {
    const displayName = benchSubjectNameBuild(settings.newSubject.typeKey, settings.newSubject.subtypeKey);
    const existing = settings.subjects.find((subject) => subjectLabelBuild(subject).trim().toLowerCase() === displayName.toLowerCase() && String(subject.subjectId || "").trim());
    if (existing) return { subjectId: String(existing.subjectId) };
    return { newSubject: { typeKey: settings.newSubject.typeKey, subtypeKey: settings.newSubject.subtypeKey, displayName } };
  }

  function benchSubjectNameBuild(typeKey: string, subtypeKey: string): string {
    return formatNotebookSaveMessage(notebookSaveMessages.benchSubject, {
      kind: subjectKindLabelBuild(typeKey, subtypeKey).toLowerCase(),
    });
  }

  function lastSubjectIdRead(): string {
    try {
      return String(globalThis.localStorage?.getItem(LAST_SUBJECT_STORAGE_KEY) || "");
    } catch {
      return "";
    }
  }

  function lastSubjectIdWrite(subjectId: string): void {
    try {
      globalThis.localStorage?.setItem(LAST_SUBJECT_STORAGE_KEY, subjectId);
    } catch {
      // Storage may be unavailable; the default simply falls back to the first subject.
    }
  }

  // ---- markup ----

  function notebookSaveModalElementBuild(settings: NotebookSaveModalSettings): HTMLDivElement {
    const modal = document.createElement("div");
    modal.className = "save-modal save-modal--entry";
    modal.innerHTML = notebookSaveModalMarkupBuild(settings);
    return modal;
  }

  function notebookSaveModalMarkupBuild(settings: NotebookSaveModalSettings): string {
    return `
      <div class="save-modal__backdrop" data-save-modal-close></div>
      <form class="save-modal__panel save-modal__entry" role="dialog" aria-modal="true" aria-label="${escapeHtml(settings.dialogLabel)}">
        <div class="save-modal__kicker">
          <span class="save-modal__kicker-to">${escapeHtml(formatNotebookSaveMessage(notebookSaveMessages.toNotebook, { notebookName: settings.notebookName }))}</span>
          <time class="save-modal__kicker-when" datetime="${escapeHtml(new Date().toISOString())}">${escapeHtml(whenLabelBuild(new Date()))}</time>
        </div>
        ${subjectMarkupBuild(settings)}
        <input type="text" name="event_summary" class="save-modal__title" value="${escapeHtml(settings.title)}" aria-label="${escapeHtml(notebookSaveMessages.entryTitle)}" autocomplete="off">
        ${listeningMarkupBuild(settings)}
        ${summaryMarkupBuild(settings)}
        <p class="save-modal__files">${settings.packageFiles.map((file) => escapeHtml(file)).join(" · ")}</p>
        <p class="save-modal__error" data-save-modal-error hidden></p>
        <footer class="save-modal__footer">
          <button type="button" class="ghost-btn" data-save-modal-close>${escapeHtml(notebookSaveMessages.cancel)}</button>
          <button type="submit" class="primary-btn hero-control" data-save-modal-submit>${escapeHtml(notebookSaveMessages.save)}</button>
        </footer>
      </form>`;
  }

  function whenLabelBuild(date: Date): string {
    try {
      return date.toLocaleString(notebookSaveMessages.locale, { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
    } catch {
      return date.toISOString();
    }
  }

  function subjectMarkupBuild(settings: NotebookSaveModalSettings): string {
    return `
        <div class="save-modal__subject" data-save-modal-picker>
          <button type="button" class="save-modal__subject-name" data-save-modal-subject aria-haspopup="listbox" aria-expanded="false" title="${escapeHtml(notebookSaveMessages.changeSubject)}"></button>
          <span class="save-modal__subject-kind" data-save-modal-subject-kind></span>
          <div class="save-modal__menu" data-save-modal-menu hidden>
            <input type="search" name="subject_filter" placeholder="${escapeHtml(subjectFilterPlaceholderBuild(settings))}" aria-label="${escapeHtml(notebookSaveMessages.findOrCreateSubject)}" autocomplete="off">
            <div class="save-modal__options" role="listbox" data-save-modal-options>${subjectOptionsMarkupBuild(settings.subjects)}</div>
            <div class="save-modal__create" data-save-modal-create-row hidden>
              <button type="button" class="save-modal__option save-modal__option--create" data-save-modal-create>${escapeHtml(formatNotebookSaveMessage(notebookSaveMessages.createSubject, { name: "" }))}</button>
              ${settings.newSubject.typeChoice ? subjectTypeChoiceMarkupBuild(settings.newSubject) : `<span class="save-modal__create-kind">${escapeHtml(formatNotebookSaveMessage(notebookSaveMessages.asKind, { kind: subjectKindLabelBuild(settings.newSubject.typeKey, settings.newSubject.subtypeKey).toLowerCase() }))}</span>`}
            </div>
          </div>
        </div>`;
  }

  function subjectFilterPlaceholderBuild(settings: NotebookSaveModalSettings): string {
    return settings.subjects.length
      ? notebookSaveMessages.findOrCreateSubject
      : formatNotebookSaveMessage(notebookSaveMessages.nameExample, {
        example: settings.newSubject.displayNamePlaceholder,
      });
  }

  function subjectOptionsMarkupBuild(subjects: NotebookSaveSubject[]): string {
    const groups = new Map<string, NotebookSaveSubject[]>();
    subjects.forEach((subject) => {
      const kind = subjectGroupLabelBuild(subject);
      if (!groups.has(kind)) groups.set(kind, []);
      groups.get(kind)!.push(subject);
    });
    return Array.from(groups.entries())
      .map(([kind, members]) => `<div class="save-modal__group" data-save-modal-group>${groups.size > 1 || kind ? `<div class="save-modal__group-label">${escapeHtml(kind)}</div>` : ""}${members.map(subjectOptionMarkupBuild).join("")}</div>`)
      .join("");
  }

  function subjectOptionMarkupBuild(subject: NotebookSaveSubject): string {
    const id = String(subject.subjectId || "");
    const label = subjectLabelBuild(subject);
    return `<button type="button" role="option" class="save-modal__option" data-save-modal-option data-subject-id="${escapeHtml(id)}" data-subject-label="${escapeHtml(label.toLowerCase())}">${escapeHtml(label)}</button>`;
  }

  function subjectLabelBuild(subject: NotebookSaveSubject | undefined): string {
    return String(subject?.displayName || subject?.subjectId || "");
  }

  function subjectGroupLabelBuild(subject: NotebookSaveSubject): string {
    const typeKey = String(subject.typeKey || "").trim().toUpperCase();
    if (!typeKey) return "";
    const type = SUBJECT_TYPE_OPTIONS.find((option) => option.key === typeKey);
    return type ? type.groupLabel : typeKey.charAt(0) + typeKey.slice(1).toLowerCase().replace(/_/g, " ");
  }

  function subjectKindLabelBuild(typeKey: string, subtypeKey: string): string {
    const type = SUBJECT_TYPE_OPTIONS.find((option) => option.key === String(typeKey || "").toUpperCase());
    const subtype = type?.subtypes.find((option) => option.key === String(subtypeKey || "").toUpperCase() && option.key);
    return subtype ? `${subtype.label}` : type ? type.label : notebookSaveMessages.subject;
  }

  function subjectTypeChoiceMarkupBuild(newSubject: NotebookSaveNewSubjectSettings): string {
    return `
              <span class="save-modal__create-kind">as</span>
              <select name="type_key" aria-label="${escapeHtml(notebookSaveMessages.type)}">${selectOptionsMarkupBuild(notebookSubjectTypeOptionsRead(), newSubject.typeKey)}</select>
              <select name="subtype_key" aria-label="${escapeHtml(notebookSaveMessages.subtype)}">${selectOptionsMarkupBuild(notebookSubjectSubtypeOptionsRead(newSubject.typeKey), newSubject.subtypeKey)}</select>`;
  }

  function listeningMarkupBuild(settings: NotebookSaveModalSettings): string {
    return `
        <div class="save-modal__listening">
          <label class="save-modal__heard"><span class="save-modal__heard-label">${escapeHtml(notebookSaveMessages.heard)}</span><input type="text" name="heard_note" placeholder="${escapeHtml(notebookSaveMessages.heardPlaceholder)}" autocomplete="off"></label>
          <div class="save-modal__pills" role="group" aria-label="${escapeHtml(notebookSaveMessages.whatYouHeard)}">${settings.listening.descriptors.map(listeningPillMarkupBuild).join("")}</div>
        </div>`;
  }

  function listeningPillMarkupBuild(descriptor: ListeningDescriptor): string {
    return `<button type="button" class="save-modal__pill" name="heard_descriptor" value="${escapeHtml(descriptor.value)}" aria-pressed="false">${escapeHtml(descriptor.label)}</button>`;
  }

  function summaryMarkupBuild(settings: NotebookSaveModalSettings): string {
    if (!settings.summary.length) return "";
    return `
        <dl class="save-modal__summary">${settings.summary.map(summaryRowMarkupBuild).join("")}</dl>`;
  }

  // Provenance is printed only when it has something to say: a measured value
  // is the expectation, a modeled, calculated or default one is worth a word.
  function summaryRowMarkupBuild(row: NotebookSaveSummaryRow): string {
    const provenance = row.provenance && row.provenance !== "measured"
      ? `<span class="save-modal__provenance save-modal__provenance--${escapeHtml(row.provenance)}">${escapeHtml(PROVENANCE_LABELS[row.provenance])}</span>`
      : "";
    return `<div class="save-modal__summary-row"><dt>${escapeHtml(row.label)}</dt><dd>${escapeHtml(row.value)}</dd>${provenance}</div>`;
  }

  // ---- behaviour ----

  function notebookSaveModalBindingsAttach(
    modal: HTMLElement,
    settings: NotebookSaveModalSettings,
    picker: PickerState,
    closeWith: (result: NotebookSaveModalResult) => void,
  ): () => void {
    closeBindingsAttach(modal, closeWith);
    pillBindingsAttach(modal);
    subjectTypeBindingsAttach(modal, settings);
    const detachPicker = pickerBindingsAttach(modal, settings, picker);
    submitBindingAttach(modal, settings, picker, closeWith);
    return detachPicker;
  }

  function closeBindingsAttach(modal: HTMLElement, closeWith: (result: NotebookSaveModalResult) => void): void {
    modal.querySelectorAll<HTMLElement>("[data-save-modal-close]").forEach((element) => {
      element.addEventListener("click", () => closeWith(null));
    });
  }

  function pillBindingsAttach(modal: HTMLElement): void {
    modal.querySelectorAll<HTMLButtonElement>(".save-modal__pill").forEach((pill) => {
      pill.addEventListener("click", () => {
        pill.setAttribute("aria-pressed", pill.getAttribute("aria-pressed") === "true" ? "false" : "true");
      });
    });
  }

  function subjectTypeBindingsAttach(modal: HTMLElement, settings: NotebookSaveModalSettings): void {
    if (!settings.newSubject.typeChoice) return;
    const typeSelect = modal.querySelector<HTMLSelectElement>('select[name="type_key"]');
    const subtypeSelect = modal.querySelector<HTMLSelectElement>('select[name="subtype_key"]');
    if (!typeSelect || !subtypeSelect) return;
    typeSelect.addEventListener("change", () => subtypeOptionsRender(subtypeSelect, typeSelect.value, ""));
  }

  function pickerBindingsAttach(modal: HTMLElement, settings: NotebookSaveModalSettings, picker: PickerState): () => void {
    const trigger = modal.querySelector<HTMLButtonElement>("[data-save-modal-subject]");
    const filter = modal.querySelector<HTMLInputElement>('input[name="subject_filter"]');
    const create = modal.querySelector<HTMLButtonElement>("[data-save-modal-create]");
    if (!trigger || !filter || !create) return () => {};

    trigger.addEventListener("click", () => pickerToggle(modal, settings, picker, !picker.open));
    filter.addEventListener("input", () => pickerFilterRender(modal, filter.value));
    filter.addEventListener("keydown", (event) => pickerKeydownHandle(event, modal, settings, picker));
    create.addEventListener("click", () => subjectCreateChoose(modal, settings, picker));
    modal.querySelectorAll<HTMLButtonElement>("[data-save-modal-option]").forEach((option) => {
      option.addEventListener("click", () => subjectChoose(modal, settings, picker, { subjectId: String(option.dataset.subjectId || "") }));
    });

    const outsideClick = (event: Event) => {
      if (!picker.open) return;
      const target = event.target as Node | null;
      const pickerElement = modal.querySelector("[data-save-modal-picker]");
      if (pickerElement && target && !pickerElement.contains(target)) pickerToggle(modal, settings, picker, false);
    };
    modal.addEventListener("click", outsideClick);
    return () => modal.removeEventListener("click", outsideClick);
  }

  function pickerKeydownHandle(event: KeyboardEvent, modal: HTMLElement, settings: NotebookSaveModalSettings, picker: PickerState): void {
    if (event.key === "Escape") {
      event.preventDefault();
      pickerToggle(modal, settings, picker, false);
      return;
    }
    if (event.key !== "Enter") return;
    event.preventDefault();
    const visible = pickerVisibleOptionsRead(modal);
    if (visible.length === 1) {
      subjectChoose(modal, settings, picker, { subjectId: String(visible[0].dataset.subjectId || "") });
      return;
    }
    if (pickerCreateAvailable(modal)) subjectCreateChoose(modal, settings, picker);
  }

  function pickerToggle(modal: HTMLElement, settings: NotebookSaveModalSettings, picker: PickerState, open: boolean): void {
    picker.open = open;
    const menu = modal.querySelector<HTMLElement>("[data-save-modal-menu]");
    const trigger = modal.querySelector<HTMLElement>("[data-save-modal-subject]");
    const filter = modal.querySelector<HTMLInputElement>('input[name="subject_filter"]');
    if (menu) menu.hidden = !open;
    if (trigger) trigger.setAttribute("aria-expanded", open ? "true" : "false");
    if (open && filter) {
      filter.value = "";
      pickerFilterRender(modal, "");
      filter.focus();
    }
  }

  function pickerFilterRender(modal: HTMLElement, text: string): void {
    const needle = String(text || "").trim().toLowerCase();
    let exactMatch = false;
    modal.querySelectorAll<HTMLButtonElement>("[data-save-modal-option]").forEach((option) => {
      const label = String(option.dataset.subjectLabel || "");
      const hit = !needle || label.includes(needle);
      option.hidden = !hit;
      if (hit && label === needle) exactMatch = true;
    });
    modal.querySelectorAll<HTMLElement>("[data-save-modal-group]").forEach((group) => {
      group.hidden = !group.querySelector("[data-save-modal-option]:not([hidden])");
    });
    const createRow = modal.querySelector<HTMLElement>("[data-save-modal-create-row]");
    const create = modal.querySelector<HTMLElement>("[data-save-modal-create]");
    if (createRow) createRow.hidden = !needle || exactMatch;
    if (create) {
      create.textContent = formatNotebookSaveMessage(notebookSaveMessages.createSubject, {
        name: String(text || "").trim(),
      });
    }
  }

  function pickerVisibleOptionsRead(modal: HTMLElement): HTMLButtonElement[] {
    return Array.from(modal.querySelectorAll<HTMLButtonElement>("[data-save-modal-option]")).filter((option) => !option.hidden);
  }

  function pickerCreateAvailable(modal: HTMLElement): boolean {
    const createRow = modal.querySelector<HTMLElement>("[data-save-modal-create-row]");
    return Boolean(createRow && !createRow.hidden);
  }

  function subjectChoose(modal: HTMLElement, settings: NotebookSaveModalSettings, picker: PickerState, choice: NotebookSaveSubjectChoice): void {
    picker.choice = choice;
    pickerToggle(modal, settings, picker, false);
    subjectRender(modal, settings, picker);
    errorRender(modal.querySelector<HTMLElement>("[data-save-modal-error]"), "");
  }

  function subjectCreateChoose(modal: HTMLElement, settings: NotebookSaveModalSettings, picker: PickerState): void {
    const displayName = fieldValueRead(modal, 'input[name="subject_filter"]').trim();
    if (!displayName) return;
    subjectChoose(modal, settings, picker, {
      newSubject: {
        typeKey: newSubjectTypeKeyRead(modal, settings),
        subtypeKey: newSubjectSubtypeKeyRead(modal, settings),
        displayName,
      },
    });
  }

  function subjectRender(modal: HTMLElement, settings: NotebookSaveModalSettings, picker: PickerState): void {
    const trigger = modal.querySelector<HTMLElement>("[data-save-modal-subject]");
    const kind = modal.querySelector<HTMLElement>("[data-save-modal-subject-kind]");
    const submit = modal.querySelector<HTMLElement>("[data-save-modal-submit]");
    const name = subjectChoiceNameBuild(settings, picker.choice);
    if (trigger) trigger.textContent = name ? `${name} ▾` : `${notebookSaveMessages.chooseSubject} ▾`;
    if (kind) kind.textContent = subjectChoiceKindBuild(settings, picker.choice);
    if (submit) {
      submit.textContent = name
        ? formatNotebookSaveMessage(notebookSaveMessages.saveToSubject, { subject: subjectShortNameBuild(name) })
        : notebookSaveMessages.save;
    }
  }

  function subjectChoiceNameBuild(settings: NotebookSaveModalSettings, choice: NotebookSaveSubjectChoice | null): string {
    if (!choice) return "";
    if ("newSubject" in choice) return choice.newSubject.displayName;
    return subjectLabelBuild(settings.subjects.find((subject) => String(subject.subjectId || "") === choice.subjectId));
  }

  function subjectChoiceKindBuild(settings: NotebookSaveModalSettings, choice: NotebookSaveSubjectChoice | null): string {
    if (!choice) return settings.subjects.length ? "" : notebookSaveMessages.nothingInNotebook;
    if ("newSubject" in choice) {
      return formatNotebookSaveMessage(notebookSaveMessages.newSubjectKind, {
        kind: subjectKindLabelBuild(choice.newSubject.typeKey, choice.newSubject.subtypeKey).toLowerCase(),
      });
    }
    const subject = settings.subjects.find((item) => String(item.subjectId || "") === choice.subjectId);
    return subject ? subjectKindLabelBuild(String(subject.typeKey || ""), String(subject.subtypeKey || "")).replace(new RegExp(`^${escapeRegExp(notebookSaveMessages.subject)}$`), "") : "";
  }

  function subjectShortNameBuild(name: string): string {
    const short = name.replace(/\s*\(.*\)\s*$/, "").trim() || name;
    return short.length > 28 ? `${short.slice(0, 27).trim()}…` : short;
  }

  function submitBindingAttach(
    modal: HTMLElement,
    settings: NotebookSaveModalSettings,
    picker: PickerState,
    closeWith: (result: NotebookSaveModalResult) => void,
  ): void {
    const form = modal.querySelector("form");
    const error = modal.querySelector<HTMLElement>("[data-save-modal-error]");
    form?.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!picker.choice) {
        errorRender(error, notebookSaveMessages.subjectRequired);
        pickerToggle(modal, settings, picker, true);
        return;
      }
      errorRender(error, "");
      if ("subjectId" in picker.choice) lastSubjectIdWrite(picker.choice.subjectId);
      closeWith({ subject: picker.choice, event: eventRead(modal, settings) });
    });
  }

  function newSubjectTypeKeyRead(modal: HTMLElement, settings: NotebookSaveModalSettings): string {
    if (!settings.newSubject.typeChoice) return settings.newSubject.typeKey;
    return fieldValueRead(modal, 'select[name="type_key"]') || "GENERIC";
  }

  function newSubjectSubtypeKeyRead(modal: HTMLElement, settings: NotebookSaveModalSettings): string {
    if (!settings.newSubject.typeChoice) return settings.newSubject.subtypeKey;
    return fieldValueRead(modal, 'select[name="subtype_key"]');
  }

  function eventRead(modal: HTMLElement, settings: NotebookSaveModalSettings): Record<string, unknown> {
    return {
      summary: fieldValueRead(modal, 'input[name="event_summary"]').trim() || settings.title,
      note: "",
      capturedAt: new Date().toISOString(),
      ...heardRead(modal),
      ...settings.eventExtras,
    };
  }

  function heardRead(modal: HTMLElement): { heard?: { descriptors: string[]; note: string } } {
    const descriptors: string[] = [];
    modal.querySelectorAll<HTMLButtonElement>('.save-modal__pill[aria-pressed="true"]').forEach((pill) => {
      const value = String(pill.value || "").trim();
      if (value) descriptors.push(value);
    });
    const note = fieldValueRead(modal, 'input[name="heard_note"]').trim();
    if (!descriptors.length && !note) return {};
    return { heard: { descriptors, note } };
  }

  function fieldValueRead(modal: HTMLElement, selector: string): string {
    const field = modal.querySelector<HTMLInputElement>(selector);
    return String((field && field.value) || "");
  }

  function subtypeOptionsRender(subtypeSelect: HTMLSelectElement, typeKey: string, selectedKey: string): void {
    subtypeSelect.innerHTML = selectOptionsMarkupBuild(notebookSubjectSubtypeOptionsRead(typeKey), selectedKey);
  }

  function errorRender(error: HTMLElement | null, message: string): void {
    if (!error) return;
    error.hidden = !message;
    error.textContent = message;
  }

  function selectOptionsMarkupBuild(options: Array<{ key: string; label: string }>, selectedKey: string): string {
    return options
      .map((option) => `<option value="${escapeHtml(option.key)}" ${option.key === selectedKey ? "selected" : ""}>${escapeHtml(option.label)}</option>`)
      .join("");
  }

  function notebookSubjectTypeOptionsRead(): SubjectTypeOption[] {
    return SUBJECT_TYPE_OPTIONS.map((option) => ({
      ...option,
      subtypes: option.subtypes.map((subtype) => ({ ...subtype })),
    }));
  }

  function notebookSubjectSubtypeOptionsRead(typeKey: string): Array<{ key: string; label: string }> {
    const match = notebookSubjectTypeOptionsRead().find((option) => option.key === typeKey);
    return match ? match.subtypes : GENERAL_SUBTYPE_OPTIONS.map((subtype) => ({ ...subtype }));
  }

  function notebookListeningDescriptorsRead(descriptorSet?: string): string[] {
    return notebookListeningDescriptorOptionsRead(descriptorSet).map((descriptor) => descriptor.label);
  }

  function notebookListeningDescriptorOptionsRead(descriptorSet?: string): ListeningDescriptor[] {
    const key = String(descriptorSet || "instrument").trim().toLowerCase();
    return (LISTENING_DESCRIPTOR_SETS[key] || LISTENING_DESCRIPTOR_SETS.instrument)
      .map((descriptor) => ({ ...descriptor }));
  }

  function escapeHtml(value: unknown): string {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function escapeRegExp(value: string): string {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function formatNotebookSaveMessage(template: string, values: Record<string, string>): string {
    return Object.entries(values).reduce(
      (message, [key, value]) => message.split(`{${key}}`).join(value),
      template,
    );
  }

  const CommonNotebookSaveModal = {
    openNotebookSaveModal,
    notebookSubjectTypeOptionsRead,
    notebookSubjectSubtypeOptionsRead,
    notebookListeningDescriptorsRead,
  };

  const globalScope = typeof globalThis !== "undefined"
    ? globalThis
    : typeof window !== "undefined"
      ? window
      : undefined;

  if (globalScope) {
    (globalScope as any).CommonNotebookSaveModal = CommonNotebookSaveModal;
  }

  if (typeof module !== "undefined" && (module as any).exports) {
    (module as any).exports = CommonNotebookSaveModal;
  }
})();
